import { useState } from "react";
import { useGame } from "@/hooks/use-game";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export default function GameControls() {
  const { startGame, isGameActive, isLoading } = useGame();
  const { user } = useAuth();
  const { toast } = useToast();
  
  // State for bet amount and mine count
  const [betAmount, setBetAmount] = useState(10);
  const [mineCount, setMineCount] = useState(5);
  const [autoCashout, setAutoCashout] = useState(false);
  const [autoCashoutMultiplier, setAutoCashoutMultiplier] = useState("2.0");
  
  // Available mine count options
  const mineOptions = [1, 3, 5, 10, 24];
  const betPresets = [1, 5, 10, 50];
  
  // Handle bet amount changes
  const handleBetAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value) && value >= 0) {
      setBetAmount(value);
    }
  };
  
  // Handle bet amount adjustment (double or half)
  const adjustBetAmount = (factor: number) => {
    setBetAmount((prev) => {
      const newAmount = prev * factor;
      return parseFloat(newAmount.toFixed(2));
    });
  };
  
  // Handle starting the game
  const handleStartGame = () => {
    // Check if user has enough balance
    if (user && user.balance < betAmount) {
      toast({
        title: "Insufficient Balance",
        description: "Please deposit more funds or lower your bet amount.",
        variant: "destructive",
      });
      return;
    }
    
    startGame(betAmount, mineCount);
  };
  
  // Calculate max payout based on mine count
  const calculateMaxPayout = () => {
    const gridSize = 25;
    const safeTiles = gridSize - mineCount;
    const houseEdge = 0.03; // 3% house edge
    
    // This is a simplified calculation - real casinos use more complex formulas
    const fairPayout = Math.pow(gridSize / safeTiles, safeTiles - 1);
    const payout = fairPayout * (1 - houseEdge);
    
    return payout.toFixed(2);
  };
  
  return (
    <div className="bg-muted rounded-xl p-3 sm:p-4 md:p-5 border border-border">
      <h3 className="text-base sm:text-lg font-bold mb-3 sm:mb-4">Bet Settings</h3>
      
      {/* Game Controls - Responsive */}
      <div className="mb-4 sm:mb-5 md:mb-6">
        <Label className="block text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2">Bet Amount</Label>
        <div className="flex">
          <div className="flex-1 relative">
            <Input
              type="number"
              value={betAmount}
              onChange={handleBetAmountChange}
              className="pr-8 font-mono text-sm sm:text-base h-9 sm:h-10"
              disabled={isGameActive || isLoading}
              min={0}
              step={0.01}
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3">
              <span className="text-muted-foreground">$</span>
            </div>
          </div>
          <div className="flex space-x-1 ml-1">
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9 sm:h-10 sm:w-10 text-xs sm:text-sm"
              onClick={() => adjustBetAmount(0.5)}
              disabled={isGameActive || isLoading}
            >
              ½
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9 sm:h-10 sm:w-10 text-xs sm:text-sm"
              onClick={() => adjustBetAmount(2)}
              disabled={isGameActive || isLoading}
            >
              2×
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-4 gap-1 sm:gap-2 mt-2">
          {betPresets.map((preset) => (
            <Button
              key={preset}
              variant="outline"
              size="sm"
              className="text-xs sm:text-sm px-0 sm:px-2"
              onClick={() => setBetAmount(preset)}
              disabled={isGameActive || isLoading}
            >
              ${preset}
            </Button>
          ))}
        </div>
      </div>
      
      {/* Mine Count Selector - Responsive */}
      <div className="mb-4 sm:mb-5 md:mb-6">
        <Label className="block text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2">Number of Mines</Label>
        <div className="grid grid-cols-5 gap-1 sm:gap-2">
          {mineOptions.map((option) => (
            <Button
              key={option}
              variant={mineCount === option ? "default" : "outline"}
              className="text-xs sm:text-sm h-8 sm:h-9 px-0 sm:px-2"
              onClick={() => setMineCount(option)}
              disabled={isGameActive || isLoading}
            >
              {option}
            </Button>
          ))}
        </div>
        
        <div className="mt-3 sm:mt-4 bg-background p-3 sm:p-4 rounded-md">
          <div className="flex justify-between mb-1">
            <span className="text-xs sm:text-sm text-muted-foreground">Mine Count:</span>
            <span className="text-xs sm:text-sm font-medium">{mineCount}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs sm:text-sm text-muted-foreground">Max Payout:</span>
            <span className="text-xs sm:text-sm font-medium text-secondary">{calculateMaxPayout()}×</span>
          </div>
        </div>
      </div>
      
      {/* Start Game Button - Responsive */}
      <Button
        className="w-full py-2 sm:py-3 text-base sm:text-lg mb-3 sm:mb-4"
        disabled={isGameActive || isLoading || betAmount <= 0}
        onClick={handleStartGame}
      >
        {isLoading ? "Starting Game..." : isGameActive ? "Game In Progress" : "Start Game"}
      </Button>
      
      {/* Auto Cash Out Toggle - Responsive */}
      <div className="bg-background p-3 sm:p-4 rounded-md">
        <div className="flex items-center justify-between mb-2 sm:mb-3">
          <Label htmlFor="auto-cashout" className="text-xs sm:text-sm text-muted-foreground">
            Auto Cash Out
          </Label>
          <Switch
            id="auto-cashout"
            checked={autoCashout}
            onCheckedChange={setAutoCashout}
            disabled={isGameActive || isLoading}
          />
        </div>
        <div>
          <Input
            type="text"
            placeholder="Target Multiplier, e.g. 2.5×"
            value={autoCashoutMultiplier}
            onChange={(e) => setAutoCashoutMultiplier(e.target.value)}
            disabled={!autoCashout || isGameActive || isLoading}
            className="text-xs sm:text-sm h-8 sm:h-9"
          />
        </div>
      </div>
    </div>
  );
}
