import { useGame, TileState } from "@/hooks/use-game";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useState } from "react";

interface GameBoardProps {
  gridSize?: number;
}

export default function GameBoard({ gridSize = 5 }: GameBoardProps) {
  const {
    isGameActive,
    tiles,
    currentMultiplier,
    potentialWin,
    cashout,
    isLoading,
    serverSeedHash,
    error,
    clearError,
    clickTile
  } = useGame();
  
  const [showErrorDialog, setShowErrorDialog] = useState(!!error);
  
  // Close error dialog and clear error
  const handleCloseErrorDialog = () => {
    setShowErrorDialog(false);
    clearError();
  };
  
  // Show error dialog when error occurs
  if (error && !showErrorDialog) {
    setShowErrorDialog(true);
  }
  
  // Format numbers with currency
  const formatMoney = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(amount);
  };
  
  // Format multiplier
  const formatMultiplier = (multiplier: number) => {
    return `${multiplier.toFixed(2)}×`;
  };
  
  // Render a single tile
  const renderTile = (tile: TileState) => {
    const revealedClass = tile.revealed ? 'revealed' : '';
    const mineClass = tile.revealed && tile.isMine ? 'mine' : tile.revealed ? 'safe' : '';
    const isClickable = isGameActive && !tile.revealed;
    
    return (
      <div
        key={tile.index}
        className={`tile aspect-square rounded-lg flex items-center justify-center cursor-pointer ${revealedClass} ${mineClass} ${
          isClickable ? 'bg-background border border-border hover:border-primary' : ''
        }`}
        onClick={() => isGameActive && !tile.revealed && !isLoading && clickTile(tile.index)}
      >
        {tile.revealed ? (
          tile.isMine ? (
            <span className="text-3xl">💣</span>
          ) : (
            <span className="text-2xl font-bold">{formatMultiplier(tile.multiplier || 0)}</span>
          )
        ) : (
          <span className="text-2xl">?</span>
        )}
      </div>
    );
  };
  
  return (
    <div className="bg-muted rounded-xl p-3 sm:p-4 md:p-5 border border-border">
      {/* Game Info Bar - Responsive Layout */}
      <div className="grid grid-cols-2 md:flex md:flex-wrap gap-3 md:gap-0 md:justify-between items-center mb-3 sm:mb-4 md:mb-5">
        <div className="text-center md:text-left">
          <div className="text-xs sm:text-sm text-muted-foreground mb-1">Current Multiplier</div>
          <div className="text-xl sm:text-2xl font-mono font-medium">{formatMultiplier(currentMultiplier)}</div>
        </div>
        <div className="text-center md:text-left">
          <div className="text-xs sm:text-sm text-muted-foreground mb-1">Potential Win</div>
          <div className="text-xl sm:text-2xl font-mono font-medium text-secondary">{formatMoney(potentialWin)}</div>
        </div>
        <div className="col-span-2 mt-2 md:mt-0">
          <Button
            variant="secondary"
            disabled={!isGameActive || isLoading}
            onClick={() => cashout()}
            className="w-full md:w-auto px-3 sm:px-4 md:px-5 py-2"
          >
            {isLoading ? 'Processing...' : 'Cash Out'}
          </Button>
        </div>
      </div>
      
      {/* Provably Fair Hash - More compact on mobile */}
      <div className="mb-3 sm:mb-4 md:mb-5 p-2 sm:p-3 bg-background rounded-lg">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div className="text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-0">Game Hash:</div>
          <div className="flex items-center">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <span className="font-mono text-xs text-muted-foreground truncate max-w-[200px] sm:max-w-xs">
                    {serverSeedHash || 'Start a game to see the hash'}
                  </span>
                </TooltipTrigger>
                <TooltipContent>
                  <p>This hash ensures the game is provably fair</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <Button
              variant="ghost"
              size="icon"
              className="ml-1 sm:ml-2 text-muted-foreground hover:text-foreground h-6 w-6 sm:h-8 sm:w-8"
              onClick={() => {
                if (serverSeedHash) {
                  navigator.clipboard.writeText(serverSeedHash);
                }
              }}
              disabled={!serverSeedHash}
            >
              <span className="text-xs sm:text-sm">📋</span>
            </Button>
          </div>
        </div>
      </div>
      
      {/* Game Grid - Responsive sizing and spacing */}
      <div className="grid grid-cols-5 gap-1 xs:gap-2 sm:gap-2 md:gap-3">
        {tiles.map(renderTile)}
      </div>
      
      {/* Error Dialog */}
      <AlertDialog open={showErrorDialog} onOpenChange={setShowErrorDialog}>
        <AlertDialogContent className="sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle>Error</AlertDialogTitle>
            <AlertDialogDescription>
              {error}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogAction onClick={handleCloseErrorDialog}>OK</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
