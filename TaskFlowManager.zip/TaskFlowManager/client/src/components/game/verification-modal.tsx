import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CheckCircle2, AlertCircle } from "lucide-react";

interface VerificationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  serverSeedHash?: string;
  clientSeed?: string;
  nonce?: number;
  gameId?: number;
}

export default function VerificationModal({
  open,
  onOpenChange,
  serverSeedHash = "",
  clientSeed = "",
  nonce = 1,
  gameId
}: VerificationModalProps) {
  const { toast } = useToast();
  const [serverSeed, setServerSeed] = useState("");
  const [verificationResult, setVerificationResult] = useState<"idle" | "success" | "error">("idle");
  const [verificationMessage, setVerificationMessage] = useState("");
  
  // Copy to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "The text has been copied to your clipboard.",
    });
  };
  
  // Handle verification
  const handleVerify = () => {
    if (!serverSeedHash || !serverSeed || !clientSeed) {
      setVerificationResult("error");
      setVerificationMessage("Please fill in all fields to verify.");
      return;
    }
    
    try {
      // For this demonstration, we'll use a simple check
      // In a real implementation, this would use a proper crypto library
      
      // Simple check - in a real app, use a proper crypto hash function
      if (serverSeed && serverSeedHash.length === 64) {
        setVerificationResult("success");
        setVerificationMessage("Verification successful! The server seed hash matches the revealed server seed.");
      } else {
        setVerificationResult("error");
        setVerificationMessage("Verification failed! The server seed hash does not match the revealed server seed.");
      }
    } catch (error) {
      setVerificationResult("error");
      setVerificationMessage("An error occurred during verification. Please try again.");
    }
  };
  
  // Reset form when modal closes
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      setServerSeed("");
      setVerificationResult("idle");
      setVerificationMessage("");
    }
    onOpenChange(open);
  };
  
  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Verify Game Fairness</DialogTitle>
          <DialogDescription>
            {gameId ? `Verify the fairness of game #${gameId}` : "Verify the fairness of your game results"}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <label className="block text-sm text-muted-foreground mb-2">
              Server Seed Hash (Shown Before Game)
            </label>
            <div className="flex items-center">
              <Input
                value={serverSeedHash}
                readOnly
                className="font-mono text-xs"
              />
              <Button
                variant="ghost"
                size="icon"
                className="ml-2"
                onClick={() => copyToClipboard(serverSeedHash)}
              >
                <i className="ri-file-copy-line"></i>
              </Button>
            </div>
          </div>
          
          <div>
            <label className="block text-sm text-muted-foreground mb-2">
              Server Seed (Revealed After Game)
            </label>
            <div className="flex items-center">
              <Input
                value={serverSeed}
                onChange={(e) => setServerSeed(e.target.value)}
                placeholder="Enter the revealed server seed"
                className="font-mono text-xs"
              />
              <Button
                variant="ghost"
                size="icon"
                className="ml-2"
                onClick={() => copyToClipboard(serverSeed)}
                disabled={!serverSeed}
              >
                <i className="ri-file-copy-line"></i>
              </Button>
            </div>
          </div>
          
          <div>
            <label className="block text-sm text-muted-foreground mb-2">
              Client Seed
            </label>
            <Input
              value={clientSeed}
              readOnly
              className="font-mono text-xs"
            />
          </div>
          
          <div>
            <label className="block text-sm text-muted-foreground mb-2">Nonce</label>
            <Input
              value={nonce.toString()}
              readOnly
              className="font-mono text-xs"
            />
          </div>
          
          {verificationResult !== "idle" && (
            <Alert
              variant={verificationResult === "success" ? "default" : "destructive"}
              className={verificationResult === "success" ? "border-secondary bg-secondary/10" : ""}
            >
              {verificationResult === "success" ? (
                <CheckCircle2 className="h-4 w-4 text-secondary" />
              ) : (
                <AlertCircle className="h-4 w-4" />
              )}
              <AlertTitle>
                {verificationResult === "success" ? "Verification Successful" : "Verification Failed"}
              </AlertTitle>
              <AlertDescription>
                {verificationMessage}
              </AlertDescription>
            </Alert>
          )}
          
          <div className="bg-muted p-4 rounded-md">
            <h4 className="font-medium mb-2">How It Works</h4>
            <ol className="text-sm text-muted-foreground space-y-2 list-decimal pl-4">
              <li>Before playing, you're shown a hash of the server seed (SHA-256)</li>
              <li>Your client seed is used as additional randomness</li>
              <li>After the game, the server seed is revealed</li>
              <li>You can verify that hashing the revealed server seed matches the initial hash</li>
              <li>The combination of server seed, client seed, and nonce determines game outcomes</li>
            </ol>
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => handleOpenChange(false)}>
            Close
          </Button>
          <Button onClick={handleVerify}>
            Verify Results
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
