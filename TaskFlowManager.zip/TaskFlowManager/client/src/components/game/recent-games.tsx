import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Game } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function RecentGames() {
  const { toast } = useToast();
  
  const { data: games = [], isLoading } = useQuery<Game[]>({
    queryKey: ["/api/games"],
    staleTime: 10000, // 10 seconds
  });
  
  // Format time to display relative time
  const formatTime = (timestamp: Date) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffSeconds < 60) return `${diffSeconds} sec ago`;
    if (diffSeconds < 3600) return `${Math.floor(diffSeconds / 60)} min ago`;
    if (diffSeconds < 86400) return `${Math.floor(diffSeconds / 3600)} hour${Math.floor(diffSeconds / 3600) > 1 ? 's' : ''} ago`;
    return `${Math.floor(diffSeconds / 86400)} day${Math.floor(diffSeconds / 86400) > 1 ? 's' : ''} ago`;
  };
  
  // Format hash to show truncated version
  const formatHash = (hash: string) => {
    if (!hash) return '';
    return `${hash.substring(0, 10)}...${hash.substring(hash.length - 8)}`;
  };
  
  // Copy hash to clipboard
  const copyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    toast({
      title: "Hash Copied",
      description: "Game hash copied to clipboard",
    });
  };
  
  // Render loading state
  if (isLoading) {
    return (
      <div className="mt-8">
        <h3 className="text-lg font-bold mb-4">Recent Games</h3>
        <div className="bg-muted rounded-xl overflow-hidden border border-border">
          <div className="p-6 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex flex-col space-y-2">
                <Skeleton className="h-5 w-full" />
                <Skeleton className="h-8 w-full" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }
  
  // If no games, show empty state
  if (games.length === 0) {
    return (
      <div className="mt-8">
        <h3 className="text-lg font-bold mb-4">Recent Games</h3>
        <div className="bg-muted rounded-xl overflow-hidden border border-border">
          <div className="p-12 text-center">
            <div className="text-muted-foreground mb-2">
              <i className="ri-history-line text-3xl"></i>
            </div>
            <h4 className="text-lg font-medium mb-2">No Games Yet</h4>
            <p className="text-muted-foreground mb-4">
              Start playing to see your game history here.
            </p>
          </div>
        </div>
      </div>
    );
  }
  
  // Format profit with sign and color
  const formatProfit = (profit: number) => {
    const formattedValue = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(Math.abs(profit));
    
    if (profit > 0) {
      return <span className="text-secondary">+{formattedValue}</span>;
    } else if (profit < 0) {
      return <span className="text-destructive">-{formattedValue}</span>;
    }
    return <span>{formattedValue}</span>;
  };
  
  return (
    <div className="mt-8">
      <h3 className="text-lg font-bold mb-4">Recent Games</h3>
      <div className="bg-muted rounded-xl overflow-hidden border border-border">
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="bg-background">
                <th className="py-3 px-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Time</th>
                <th className="py-3 px-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Bet Amount</th>
                <th className="py-3 px-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Mines</th>
                <th className="py-3 px-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Multiplier</th>
                <th className="py-3 px-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Profit</th>
                <th className="py-3 px-4 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">Game Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {games.slice(0, 5).map((game) => {
                const result = game.result as any;
                return (
                  <tr key={game.id} className="hover:bg-background">
                    <td className="py-3 px-4 text-sm">{formatTime(game.createdAt)}</td>
                    <td className="py-3 px-4 text-sm font-mono">${game.betAmount.toFixed(2)}</td>
                    <td className="py-3 px-4 text-sm">{game.mineCount}</td>
                    <td className="py-3 px-4 text-sm font-mono">{result.multiplier ? `${result.multiplier.toFixed(2)}×` : '0.00×'}</td>
                    <td className="py-3 px-4 text-sm font-mono">{formatProfit(game.profit)}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center">
                        <span className="font-mono text-xs text-muted-foreground truncate max-w-xs">{formatHash(game.serverSeedHash)}</span>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="ml-2 text-muted-foreground hover:text-foreground"
                          onClick={() => copyHash(game.serverSeedHash)}
                        >
                          <i className="ri-search-line"></i>
                        </Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
