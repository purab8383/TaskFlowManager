import { useLocation, Link } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/use-auth";
import UserCard from "./user-card";
import { useState } from "react";

export default function MobileNav() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [open, setOpen] = useState(false);
  
  const menuItems = [
    { path: "/game", label: "Play", icon: "ri-gamepad-line" },
    { path: "/history", label: "History", icon: "ri-history-line" },
    { path: "/wallet", label: "Wallet", icon: "ri-wallet-3-line" },
    { path: "/settings", label: "Profile", icon: "ri-user-line" },
  ];
  
  const fullMenuItems = [
    { path: "/game", label: "Mines Game", icon: "ri-gamepad-line" },
    { path: "/history", label: "Game History", icon: "ri-history-line" },
    { path: "/wallet", label: "Wallet", icon: "ri-wallet-3-line" },
    { path: "/provably-fair", label: "Provably Fair", icon: "ri-shield-check-line" },
    { path: "/settings", label: "Settings", icon: "ri-settings-4-line" },
  ];
  
  // Add admin route for admins
  if (user?.isAdmin) {
    fullMenuItems.push({ path: "/admin", label: "Admin Panel", icon: "ri-admin-line" });
  }
  
  return (
    <>
      {/* Top header for mobile */}
      <header className="md:hidden bg-muted border-b border-border p-4">
        <div className="flex justify-between items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <div className="bg-primary rounded-md p-1 mr-2">
                <i className="ri-bomb-line text-lg"></i>
              </div>
              <h1 className="font-heading font-bold text-foreground">CryptoMines</h1>
            </div>
          </Link>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <i className="ri-menu-line text-xl"></i>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[80%] sm:w-[350px]">
              <div className="flex flex-col h-full">
                <div className="py-6">
                  <UserCard />
                </div>
                
                <nav className="flex-1">
                  <ul className="space-y-1">
                    {fullMenuItems.map((item) => (
                      <li key={item.path}>
                        <Link href={item.path}>
                          <a 
                            className={cn(
                              "flex items-center px-4 py-3 rounded-md font-medium",
                              location === item.path 
                                ? "text-primary-foreground bg-primary" 
                                : "text-muted-foreground hover:text-foreground hover:bg-background"
                            )}
                            onClick={() => setOpen(false)}
                          >
                            <i className={cn(item.icon, "mr-3", location === item.path ? "text-primary-foreground" : "text-primary")}></i>
                            <span>{item.label}</span>
                          </a>
                        </Link>
                      </li>
                    ))}
                  </ul>
                </nav>
                
                <div className="py-4">
                  <Button 
                    variant="outline" 
                    className="w-full" 
                    onClick={() => logoutMutation.mutate()}
                    disabled={logoutMutation.isPending}
                  >
                    <i className="ri-logout-box-line mr-2"></i>
                    <span>Log Out</span>
                  </Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>
      
      {/* Bottom navigation for mobile */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-muted border-t border-border flex justify-around z-10">
        {menuItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a className={cn(
              "flex flex-col items-center justify-center p-2",
              location === item.path ? "text-primary" : "text-muted-foreground"
            )}>
              <i className={cn(item.icon, "text-xl")}></i>
              <span className="text-xs mt-1">{item.label}</span>
            </a>
          </Link>
        ))}
      </div>
    </>
  );
}
