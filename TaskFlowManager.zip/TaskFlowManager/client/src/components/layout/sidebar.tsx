import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import UserCard from "./user-card";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";

export default function Sidebar() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  
  const menuItems = [
    { path: "/game", label: "Mines Game", icon: "ri-gamepad-line" },
    { path: "/history", label: "Game History", icon: "ri-history-line" },
    { path: "/wallet", label: "Wallet", icon: "ri-wallet-3-line" },
    { path: "/provably-fair", label: "Provably Fair", icon: "ri-shield-check-line" },
    { path: "/settings", label: "Settings", icon: "ri-settings-4-line" },
  ];
  
  // Add admin route for admins
  if (user?.isAdmin) {
    menuItems.push({ path: "/admin", label: "Admin Panel", icon: "ri-admin-line" });
  }
  
  return (
    <aside className="hidden md:flex flex-col w-64 bg-muted border-r border-border">
      <div className="p-4 border-b border-border flex items-center">
        <div className="bg-primary rounded-md p-2 mr-3">
          <i className="ri-bomb-line text-xl"></i>
        </div>
        <Link href="/">
          <h1 className="font-heading font-bold text-xl text-foreground cursor-pointer">CryptoMines</h1>
        </Link>
      </div>
      
      <div className="px-4 py-6">
        <UserCard />
      </div>
      
      <nav className="flex-1 py-2">
        <ul className="space-y-1">
          {menuItems.map((item) => (
            <li key={item.path} className="px-2">
              <Link href={item.path}>
                <a className={cn(
                  "flex items-center px-4 py-3 rounded-md font-medium",
                  location === item.path 
                    ? "text-primary-foreground bg-primary" 
                    : "text-muted-foreground hover:text-foreground hover:bg-background"
                )}>
                  <i className={cn(item.icon, "mr-3", location === item.path ? "text-primary-foreground" : "text-primary")}></i>
                  <span>{item.label}</span>
                </a>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-border">
        <Button 
          variant="outline" 
          className="w-full" 
          onClick={() => logoutMutation.mutate()}
          disabled={logoutMutation.isPending}
        >
          <i className="ri-logout-box-line mr-2"></i>
          <span>Log Out</span>
        </Button>
      </div>
    </aside>
  );
}
