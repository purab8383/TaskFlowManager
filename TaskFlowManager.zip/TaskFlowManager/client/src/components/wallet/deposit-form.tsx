import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useWallet } from "@/hooks/use-wallet";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

const depositSchema = z.object({
  amount: z
    .number({ required_error: "Amount is required" })
    .positive("Amount must be positive")
    .min(5, "Minimum deposit is $5"),
});

export default function DepositForm() {
  const { deposit, isTransactionPending } = useWallet();
  const { user } = useAuth();
  const [paymentMethod, setPaymentMethod] = useState("card");
  
  const form = useForm<z.infer<typeof depositSchema>>({
    resolver: zodResolver(depositSchema),
    defaultValues: {
      amount: 50,
    },
  });
  
  function onSubmit(values: z.infer<typeof depositSchema>) {
    deposit(values.amount);
  }
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Deposit Funds</CardTitle>
        <CardDescription>
          Add money to your account to start playing
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={paymentMethod} onValueChange={setPaymentMethod}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="card">
              <i className="ri-bank-card-line mr-2"></i> Card
            </TabsTrigger>
            <TabsTrigger value="crypto">
              <i className="ri-bitcoin-line mr-2"></i> Crypto
            </TabsTrigger>
            <TabsTrigger value="paypal">
              <i className="ri-paypal-line mr-2"></i> PayPal
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="card" className="mt-4">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Deposit Amount</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                          <Input
                            type="number"
                            className="pl-8 font-mono"
                            {...field}
                            onChange={(e) => field.onChange(parseFloat(e.target.value))}
                          />
                        </div>
                      </FormControl>
                      <FormDescription>
                        Minimum deposit amount is $5
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="space-y-2">
                  <div className="grid grid-cols-2 gap-4">
                    <Button type="button" variant="outline" onClick={() => form.setValue("amount", 50)}>
                      $50
                    </Button>
                    <Button type="button" variant="outline" onClick={() => form.setValue("amount", 100)}>
                      $100
                    </Button>
                    <Button type="button" variant="outline" onClick={() => form.setValue("amount", 250)}>
                      $250
                    </Button>
                    <Button type="button" variant="outline" onClick={() => form.setValue("amount", 500)}>
                      $500
                    </Button>
                  </div>
                </div>
                
                <div className="bg-muted rounded-md p-4">
                  <div className="flex justify-between mb-1 text-sm">
                    <span className="text-muted-foreground">Current Balance</span>
                    <span className="font-mono">${user?.balance.toFixed(2) || '0.00'}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">After Deposit</span>
                    <span className="font-mono font-medium">
                      ${((user?.balance || 0) + (form.getValues().amount || 0)).toFixed(2)}
                    </span>
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={isTransactionPending}
                >
                  {isTransactionPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                    </>
                  ) : (
                    "Deposit Funds"
                  )}
                </Button>
              </form>
            </Form>
          </TabsContent>
          
          <TabsContent value="crypto" className="mt-4">
            <div className="text-center py-8 space-y-4">
              <div className="text-6xl mb-2">
                <i className="ri-bitcoin-line"></i>
              </div>
              <h3 className="text-lg font-medium">Crypto Deposits Coming Soon</h3>
              <p className="text-muted-foreground">
                We're working on adding cryptocurrency deposit options.
                Please use card payments for now.
              </p>
              <Button variant="outline" onClick={() => setPaymentMethod("card")}>
                Use Card Instead
              </Button>
            </div>
          </TabsContent>
          
          <TabsContent value="paypal" className="mt-4">
            <div className="text-center py-8 space-y-4">
              <div className="text-6xl mb-2">
                <i className="ri-paypal-line"></i>
              </div>
              <h3 className="text-lg font-medium">PayPal Integration Coming Soon</h3>
              <p className="text-muted-foreground">
                We're working on adding PayPal as a payment option.
                Please use card payments for now.
              </p>
              <Button variant="outline" onClick={() => setPaymentMethod("card")}>
                Use Card Instead
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex flex-col">
        <p className="text-xs text-muted-foreground text-center">
          All transactions are secure and encrypted. This is a simulated payment system for demonstration purposes.
        </p>
      </CardFooter>
    </Card>
  );
}
