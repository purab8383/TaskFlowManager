import { useWallet } from "@/hooks/use-wallet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Transaction } from "@shared/schema";
import { ArrowDownCircle, ArrowUpCircle, Gamepad, Trophy, DownloadIcon, History } from "lucide-react";

export default function TransactionHistory() {
  const { transactions, isLoading } = useWallet();
  
  // Format date
  const formatDateTime = (timestamp: Date) => {
    const date = new Date(timestamp);
    // Always return a shorter format as we're handling the display responsively with CSS
    return date.toLocaleString();
  };
  
  // Format transaction amount
  const formatAmount = (amount: number) => {
    const formattedValue = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(Math.abs(amount));
    
    return amount >= 0 ? formattedValue : `-${formattedValue}`;
  };
  
  // Get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge className="bg-secondary text-xs">Completed</Badge>;
      case 'pending':
        return <Badge variant="outline" className="text-yellow-500 border-yellow-500 text-xs">Pending</Badge>;
      case 'rejected':
        return <Badge variant="destructive" className="text-xs">Rejected</Badge>;
      default:
        return <Badge variant="outline" className="text-xs">{status}</Badge>;
    }
  };
  
  // Get transaction icon
  const getTransactionIcon = (type: string) => {    
    switch (type) {
      case 'deposit':
        return <ArrowDownCircle className="text-green-500 h-4 w-4 sm:h-5 sm:w-5" />;
      case 'withdraw':
        return <ArrowUpCircle className="text-red-500 h-4 w-4 sm:h-5 sm:w-5" />;
      case 'bet':
        return <Gamepad className="text-yellow-500 h-4 w-4 sm:h-5 sm:w-5" />;
      case 'win':
        return <Trophy className="text-green-500 h-4 w-4 sm:h-5 sm:w-5" />;
      default:
        return <ArrowDownCircle className="text-muted-foreground h-4 w-4 sm:h-5 sm:w-5" />;
    }
  };
  
  // Get transaction type display name
  const getTransactionType = (type: string) => {
    switch (type) {
      case 'deposit':
        return 'Deposit';
      case 'withdraw':
        return 'Withdrawal';
      case 'bet':
        return 'Game Bet';
      case 'win':
        return 'Game Win';
      default:
        return type;
    }
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="px-3 sm:px-6 py-3 sm:py-4">
          <CardTitle className="text-base sm:text-lg">Transaction History</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 sm:space-y-4 p-3 sm:p-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex flex-wrap justify-between items-center border-b border-border pb-3 sm:pb-4">
              <div className="flex items-center">
                <Skeleton className="h-7 w-7 sm:h-8 sm:w-8 rounded-full" />
                <div className="ml-2 sm:ml-3">
                  <Skeleton className="h-3 sm:h-4 w-16 sm:w-24 mb-1" />
                  <Skeleton className="h-2 sm:h-3 w-24 sm:w-32" />
                </div>
              </div>
              <div className="mt-2 sm:mt-0">
                <Skeleton className="h-5 sm:h-6 w-16 sm:w-20" />
              </div>
              <div className="mt-2 sm:mt-0">
                <Skeleton className="h-5 sm:h-6 w-16 sm:w-20" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between px-3 sm:px-6 py-3 sm:py-4">
        <CardTitle className="text-base sm:text-lg">Transaction History</CardTitle>
        <Button variant="outline" size="sm" className="h-8 text-xs sm:text-sm">
          <DownloadIcon className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
          Export
        </Button>
      </CardHeader>
      <CardContent className="p-3 sm:p-6">
        {transactions.length === 0 ? (
          <div className="text-center py-6 sm:py-10">
            <div className="text-muted-foreground mb-2">
              <History className="h-8 w-8 sm:h-10 sm:w-10 mx-auto" />
            </div>
            <h3 className="text-base sm:text-lg font-medium mb-1 sm:mb-2">No Transactions Yet</h3>
            <p className="text-xs sm:text-sm text-muted-foreground mb-3 sm:mb-4 max-w-sm mx-auto">
              Your transaction history will appear here once you make deposits, withdrawals or bets.
            </p>
          </div>
        ) : (
          <div className="space-y-3 sm:space-y-4">
            {/* Mobile Column Headers - Only visible on small screens */}
            <div className="grid grid-cols-3 text-xs text-muted-foreground mb-1 sm:hidden px-1">
              <div>Transaction</div>
              <div className="text-center">Status</div>
              <div className="text-right">Amount</div>
            </div>
            
            {transactions.map((transaction: Transaction) => (
              <div key={transaction.id} className="grid grid-cols-3 sm:flex sm:flex-wrap sm:justify-between items-center border-b border-border pb-3 sm:pb-4">
                {/* Transaction Info - Responsive Layout */}
                <div className="col-span-1 sm:flex sm:items-center">
                  <div className="hidden sm:block sm:mr-3">
                    {getTransactionIcon(transaction.type)}
                  </div>
                  <div>
                    <p className="font-medium text-xs sm:text-sm">{getTransactionType(transaction.type)}</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">
                      {formatDateTime(transaction.createdAt)}
                    </p>
                  </div>
                </div>
                
                {/* Status Badge - Centered on mobile */}
                <div className="col-span-1 flex justify-center sm:justify-start sm:mt-0">
                  {getStatusBadge(transaction.status)}
                </div>
                
                {/* Amount - Right aligned */}
                <div className="col-span-1 font-mono font-medium text-xs sm:text-sm text-right sm:text-left sm:mt-0">
                  <span className={transaction.amount >= 0 ? 'text-green-500' : 'text-red-500'}>
                    {formatAmount(transaction.amount)}
                  </span>
                </div>
              </div>
            ))}
            
            {transactions.length > 0 && (
              <div className="text-center pt-3 sm:pt-4">
                <Button variant="outline" size="sm" className="text-xs sm:text-sm h-8">
                  View All Transactions
                </Button>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
