import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useWallet } from "@/hooks/use-wallet";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

const withdrawSchema = z.object({
  amount: z
    .number({ required_error: "Amount is required" })
    .positive("Amount must be positive")
    .min(10, "Minimum withdrawal is $10"),
});

export default function WithdrawForm() {
  const { withdraw, isTransactionPending } = useWallet();
  const { user } = useAuth();
  
  const form = useForm<z.infer<typeof withdrawSchema>>({
    resolver: zodResolver(withdrawSchema),
    defaultValues: {
      amount: 50,
    },
  });
  
  function onSubmit(values: z.infer<typeof withdrawSchema>) {
    // Check if user has enough balance
    if (user && values.amount > user.balance) {
      form.setError("amount", {
        type: "manual",
        message: "Insufficient balance for this withdrawal",
      });
      return;
    }
    
    withdraw(values.amount);
  }
  
  // Set max amount to withdraw (user's balance)
  const setMaxAmount = () => {
    if (user) {
      form.setValue("amount", Math.floor(user.balance * 100) / 100);
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Withdraw Funds</CardTitle>
        <CardDescription>
          Withdraw money from your account
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Withdrawal Amount</FormLabel>
                  <FormControl>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">$</span>
                      <Input
                        type="number"
                        className="pl-8 font-mono"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </div>
                  </FormControl>
                  <FormDescription className="flex justify-between">
                    <span>Minimum withdrawal amount is $10</span>
                    <Button 
                      type="button" 
                      variant="link" 
                      className="p-0 h-auto text-primary" 
                      onClick={setMaxAmount}
                    >
                      Max: ${user?.balance.toFixed(2) || '0.00'}
                    </Button>
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-4">
                <Button type="button" variant="outline" onClick={() => form.setValue("amount", 50)}>
                  $50
                </Button>
                <Button type="button" variant="outline" onClick={() => form.setValue("amount", 100)}>
                  $100
                </Button>
                <Button type="button" variant="outline" onClick={() => form.setValue("amount", 250)}>
                  $250
                </Button>
                <Button type="button" variant="outline" onClick={() => form.setValue("amount", 500)}>
                  $500
                </Button>
              </div>
            </div>
            
            <div className="bg-muted rounded-md p-4">
              <div className="flex justify-between mb-1 text-sm">
                <span className="text-muted-foreground">Current Balance</span>
                <span className="font-mono">${user?.balance.toFixed(2) || '0.00'}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">After Withdrawal</span>
                <span className="font-mono font-medium">
                  ${((user?.balance || 0) - (form.getValues().amount || 0)).toFixed(2)}
                </span>
              </div>
            </div>
            
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-md p-4 text-sm">
              <div className="flex items-start">
                <i className="ri-information-line text-yellow-500 mr-2 mt-0.5"></i>
                <div>
                  <p className="font-medium text-yellow-500">Important Notice</p>
                  <p className="text-muted-foreground">
                    Withdrawals are processed manually within 24 hours. You will receive an email notification when your 
                    withdrawal is approved.
                  </p>
                </div>
              </div>
            </div>
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isTransactionPending}
            >
              {isTransactionPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                </>
              ) : (
                "Withdraw Funds"
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex flex-col">
        <p className="text-xs text-muted-foreground text-center">
          All withdrawals are subject to review. Please ensure your account details are up to date.
        </p>
      </CardFooter>
    </Card>
  );
}
