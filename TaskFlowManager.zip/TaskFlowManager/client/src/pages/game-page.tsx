import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { GameProvider } from "@/hooks/use-game";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";
import GameBoard from "@/components/game/game-board";
import GameControls from "@/components/game/game-controls";
import { ArrowLeft } from "lucide-react";

export default function GamePage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();

  return (
    <GameProvider>
      <div className="min-h-screen p-3 sm:p-4 md:p-8">
        <div className="max-w-5xl mx-auto">
          {/* Header with responsive design */}
          <div className="flex flex-wrap justify-between items-center mb-4 sm:mb-6">
            <div className="w-full sm:w-auto mb-3 sm:mb-0">
              <h2 className="text-xl sm:text-2xl font-heading font-bold text-foreground">Mines Game</h2>
              <p className="text-xs sm:text-sm text-muted-foreground">Uncover tiles, avoid mines, win big!</p>
            </div>
            <div className="flex items-center space-x-2 sm:space-x-4 w-full sm:w-auto justify-between sm:justify-end">
              {/* Mobile and Desktop Balance Card */}
              {user && (
                <Card className="bg-background px-3 sm:px-4 py-2 border border-border flex items-center flex-1 sm:flex-none mr-2 sm:mr-0">
                  <div className="mr-2 sm:mr-3">
                    <div className="text-xs text-muted-foreground">Balance</div>
                    <div className="font-mono font-medium">${user.balance.toFixed(2)}</div>
                  </div>
                  <Button size="sm" className="text-xs sm:text-sm px-2 sm:px-3" onClick={() => navigate("/wallet")}>
                    Deposit
                  </Button>
                </Card>
              )}
              <Button variant="outline" size="sm" className="h-10" onClick={() => navigate("/")}>
                <ArrowLeft className="h-4 w-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Home</span>
              </Button>
            </div>
          </div>
          
          {/* Responsive Game Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-6">
            {/* Game Board - First on mobile, Second on desktop */}
            <div className="lg:col-span-2 order-1 lg:order-2">
              <GameBoard />
            </div>
            
            {/* Game Controls - Second on mobile, First on desktop */}
            <div className="lg:col-span-1 order-2 lg:order-1">
              <GameControls />
            </div>
          </div>
          
          {/* Sticky mobile bottom bar for quick actions (visible only on small screens) */}
          <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border p-3 flex justify-between items-center lg:hidden">
            <Button variant="outline" size="sm" onClick={() => navigate("/")}>
              <ArrowLeft className="h-4 w-4 mr-1" /> Home
            </Button>
            {user && (
              <div className="text-xs">
                <span className="text-muted-foreground mr-1">Balance:</span>
                <span className="font-mono font-medium">${user.balance.toFixed(2)}</span>
              </div>
            )}
            <Button size="sm" variant="secondary" onClick={() => navigate("/wallet")}>
              Deposit
            </Button>
          </div>
          {/* Add padding to prevent content from being hidden behind the sticky bar on mobile */}
          <div className="pb-16 lg:pb-0"></div>
        </div>
      </div>
    </GameProvider>
  );
}