import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Game } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function HistoryPage() {
  const { toast } = useToast();
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  
  const { data: games = [], isLoading } = useQuery<Game[]>({
    queryKey: ["/api/games"],
    staleTime: 30000, // 30 seconds
  });
  
  // Format time
  const formatDateTime = (timestamp: Date) => {
    return new Date(timestamp).toLocaleString();
  };
  
  // Copy hash to clipboard
  const copyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    toast({
      title: "Hash Copied",
      description: "Game hash copied to clipboard",
    });
  };
  
  // Format profit with sign and color
  const formatProfit = (profit: number) => {
    const formattedValue = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(Math.abs(profit));
    
    if (profit > 0) {
      return <span className="text-secondary">+{formattedValue}</span>;
    } else if (profit < 0) {
      return <span className="text-destructive">-{formattedValue}</span>;
    }
    return <span>{formattedValue}</span>;
  };
  
  // Get status badge
  const getStatusBadge = (status: string) => {
    if (status === 'won') {
      return <Badge className="bg-secondary">Won</Badge>;
    } else if (status === 'lost') {
      return <Badge variant="destructive">Lost</Badge>;
    } else {
      return <Badge variant="outline">Active</Badge>;
    }
  };
  
  // View game details
  const viewGameDetails = (game: Game) => {
    setSelectedGame(game);
    setShowDetails(true);
  };
  
  // Render loading state
  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <Sidebar />
        
        <main className="flex-1 flex flex-col pb-16 md:pb-0">
          <MobileNav />
          
          <div className="flex-1 overflow-auto p-4 md:p-8">
            <div className="mb-6">
              <h2 className="text-2xl font-heading font-bold text-foreground mb-2">Game History</h2>
              <p className="text-muted-foreground">View your past games and results</p>
            </div>
            
            <Card>
              <CardHeader>
                <Skeleton className="h-8 w-40" />
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <div key={i} className="border border-border rounded-md p-4">
                      <div className="flex flex-wrap justify-between mb-2">
                        <Skeleton className="h-5 w-24" />
                        <Skeleton className="h-5 w-20" />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                        <Skeleton className="h-4 w-full" />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 flex flex-col pb-16 md:pb-0">
        <MobileNav />
        
        <div className="flex-1 overflow-auto p-4 md:p-8">
          <div className="mb-6">
            <h2 className="text-2xl font-heading font-bold text-foreground mb-2">Game History</h2>
            <p className="text-muted-foreground">View your past games and results</p>
          </div>
          
          <Tabs defaultValue="all" className="space-y-6">
            <TabsList>
              <TabsTrigger value="all">All Games</TabsTrigger>
              <TabsTrigger value="won">Won</TabsTrigger>
              <TabsTrigger value="lost">Lost</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all" className="space-y-4">
              {games.length === 0 ? (
                <Card>
                  <CardContent className="p-12 text-center">
                    <div className="text-muted-foreground mb-2">
                      <i className="ri-history-line text-5xl"></i>
                    </div>
                    <h3 className="text-xl font-medium mb-2">No Game History</h3>
                    <p className="text-muted-foreground mb-4">
                      You haven't played any games yet. Start playing to see your history here.
                    </p>
                    <Button onClick={() => window.location.href = "/game"}>
                      Play Now
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {games.map((game) => {
                    const result = game.result as any;
                    
                    return (
                      <Card key={game.id} className="overflow-hidden">
                        <CardContent className="p-0">
                          <div className="border-b border-border p-4 flex items-center justify-between flex-wrap gap-2">
                            <div className="flex items-center">
                              <div className={`mr-3 text-xl ${game.status === 'won' ? 'text-secondary' : game.status === 'lost' ? 'text-destructive' : ''}`}>
                                <i className={game.status === 'won' ? 'ri-trophy-line' : game.status === 'lost' ? 'ri-close-circle-line' : 'ri-time-line'}></i>
                              </div>
                              <div>
                                <p className="font-medium">{formatDateTime(game.createdAt)}</p>
                                <p className="text-xs text-muted-foreground">Game #{game.id}</p>
                              </div>
                            </div>
                            <div>
                              {getStatusBadge(game.status)}
                            </div>
                          </div>
                          
                          <div className="p-4">
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                              <div>
                                <p className="text-xs text-muted-foreground">Bet Amount</p>
                                <p className="font-medium font-mono">${game.betAmount.toFixed(2)}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Mines</p>
                                <p className="font-medium">{game.mineCount}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Multiplier</p>
                                <p className="font-medium font-mono">{result.multiplier ? `${result.multiplier.toFixed(2)}×` : '0.00×'}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Profit</p>
                                <p className="font-medium font-mono">{formatProfit(game.profit)}</p>
                              </div>
                            </div>
                            
                            <Button variant="outline" size="sm" onClick={() => viewGameDetails(game)}>
                              View Details
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="won" className="space-y-4">
              {games.filter(g => g.status === 'won').length === 0 ? (
                <Card>
                  <CardContent className="p-12 text-center">
                    <div className="text-muted-foreground mb-2">
                      <i className="ri-trophy-line text-5xl"></i>
                    </div>
                    <h3 className="text-xl font-medium mb-2">No Wins Yet</h3>
                    <p className="text-muted-foreground mb-4">
                      You haven't won any games yet. Keep playing for your first win!
                    </p>
                    <Button onClick={() => window.location.href = "/game"}>
                      Play Now
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {games.filter(g => g.status === 'won').map((game) => {
                    const result = game.result as any;
                    
                    return (
                      <Card key={game.id} className="overflow-hidden">
                        <CardContent className="p-0">
                          <div className="border-b border-border p-4 flex items-center justify-between flex-wrap gap-2">
                            <div className="flex items-center">
                              <div className="mr-3 text-xl text-secondary">
                                <i className="ri-trophy-line"></i>
                              </div>
                              <div>
                                <p className="font-medium">{formatDateTime(game.createdAt)}</p>
                                <p className="text-xs text-muted-foreground">Game #{game.id}</p>
                              </div>
                            </div>
                            <div>
                              <Badge className="bg-secondary">Won</Badge>
                            </div>
                          </div>
                          
                          <div className="p-4">
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                              <div>
                                <p className="text-xs text-muted-foreground">Bet Amount</p>
                                <p className="font-medium font-mono">${game.betAmount.toFixed(2)}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Mines</p>
                                <p className="font-medium">{game.mineCount}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Multiplier</p>
                                <p className="font-medium font-mono">{result.multiplier.toFixed(2)}×</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Profit</p>
                                <p className="font-medium font-mono text-secondary">+${game.profit.toFixed(2)}</p>
                              </div>
                            </div>
                            
                            <Button variant="outline" size="sm" onClick={() => viewGameDetails(game)}>
                              View Details
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="lost" className="space-y-4">
              {games.filter(g => g.status === 'lost').length === 0 ? (
                <Card>
                  <CardContent className="p-12 text-center">
                    <div className="text-muted-foreground mb-2">
                      <i className="ri-close-circle-line text-5xl"></i>
                    </div>
                    <h3 className="text-xl font-medium mb-2">No Losses</h3>
                    <p className="text-muted-foreground mb-4">
                      You haven't lost any games yet. Great luck!
                    </p>
                    <Button onClick={() => window.location.href = "/game"}>
                      Play Now
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-4">
                  {games.filter(g => g.status === 'lost').map((game) => {
                    const result = game.result as any;
                    
                    return (
                      <Card key={game.id} className="overflow-hidden">
                        <CardContent className="p-0">
                          <div className="border-b border-border p-4 flex items-center justify-between flex-wrap gap-2">
                            <div className="flex items-center">
                              <div className="mr-3 text-xl text-destructive">
                                <i className="ri-close-circle-line"></i>
                              </div>
                              <div>
                                <p className="font-medium">{formatDateTime(game.createdAt)}</p>
                                <p className="text-xs text-muted-foreground">Game #{game.id}</p>
                              </div>
                            </div>
                            <div>
                              <Badge variant="destructive">Lost</Badge>
                            </div>
                          </div>
                          
                          <div className="p-4">
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                              <div>
                                <p className="text-xs text-muted-foreground">Bet Amount</p>
                                <p className="font-medium font-mono">${game.betAmount.toFixed(2)}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Mines</p>
                                <p className="font-medium">{game.mineCount}</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Multiplier</p>
                                <p className="font-medium font-mono">0.00×</p>
                              </div>
                              <div>
                                <p className="text-xs text-muted-foreground">Loss</p>
                                <p className="font-medium font-mono text-destructive">-${Math.abs(game.profit).toFixed(2)}</p>
                              </div>
                            </div>
                            
                            <Button variant="outline" size="sm" onClick={() => viewGameDetails(game)}>
                              View Details
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      {/* Game details dialog */}
      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Game Details</DialogTitle>
            <DialogDescription>
              Game #{selectedGame?.id} - {selectedGame && formatDateTime(selectedGame.createdAt)}
            </DialogDescription>
          </DialogHeader>
          
          {selectedGame && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <p className="font-medium">{getStatusBadge(selectedGame.status)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Bet Amount</p>
                  <p className="font-medium font-mono">${selectedGame.betAmount.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Mine Count</p>
                  <p className="font-medium">{selectedGame.mineCount}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Profit/Loss</p>
                  <p className="font-medium font-mono">{formatProfit(selectedGame.profit)}</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground mb-1">Server Seed Hash</p>
                <div className="flex items-center">
                  <code className="bg-muted p-2 rounded text-xs font-mono break-all">
                    {selectedGame.serverSeedHash}
                  </code>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="ml-2"
                    onClick={() => copyHash(selectedGame.serverSeedHash)}
                  >
                    <i className="ri-file-copy-line"></i>
                  </Button>
                </div>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground mb-1">Client Seed</p>
                <code className="bg-muted p-2 rounded text-xs font-mono block break-all">
                  {selectedGame.clientSeed}
                </code>
              </div>
              
              <div>
                <p className="text-sm text-muted-foreground mb-1">Nonce</p>
                <code className="bg-muted p-2 rounded text-xs font-mono block">
                  {selectedGame.nonce}
                </code>
              </div>
              
              {selectedGame.status !== 'active' && (
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Mine Positions</p>
                  <code className="bg-muted p-2 rounded text-xs font-mono block break-all">
                    {JSON.stringify((selectedGame.result as any).mines)}
                  </code>
                </div>
              )}
              
              <div className="mt-4">
                <Button variant="outline" size="sm" className="w-full" onClick={() => window.location.href = "/provably-fair"}>
                  Verify Fairness
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
