import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useState } from "react";

export default function HomePage() {
  const [, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const handleLogout = () => {
    logoutMutation.mutate();
    setMobileMenuOpen(false);
  };
  
  return (
    <div className="min-h-screen p-3 sm:p-4 md:p-8">
      {/* Navigation header */}
      <header className="max-w-6xl mx-auto mb-6 md:mb-8 flex justify-between items-center">
        <div className="flex items-center">
          <div className="bg-primary/20 rounded-lg p-2 mr-2 sm:mr-3">
            <span className="text-xl sm:text-2xl">💣</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-heading font-bold">CryptoMines</h1>
        </div>
        
        {/* Mobile menu */}
        <div className="block md:hidden">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent className="w-[280px] sm:w-[350px]">
              <div className="flex flex-col h-full">
                <div className="py-6">
                  <div className="flex items-center mb-6">
                    <div className="bg-primary/20 rounded-lg p-2 mr-3">
                      <span className="text-xl">💣</span>
                    </div>
                    <h2 className="text-xl font-heading font-bold">CryptoMines</h2>
                  </div>
                  
                  {user && (
                    <Card className="mb-6">
                      <CardContent className="p-4">
                        <div className="mb-2">
                          <p className="text-sm text-muted-foreground">Balance</p>
                          <p className="font-mono font-medium text-lg">${user.balance.toFixed(2)}</p>
                        </div>
                        <Button size="sm" className="w-full" onClick={() => {
                          navigate("/wallet");
                          setMobileMenuOpen(false);
                        }}>
                          Deposit
                        </Button>
                      </CardContent>
                    </Card>
                  )}
                  
                  <div className="flex flex-col space-y-2">
                    <Button 
                      variant="default" 
                      onClick={() => {
                        navigate("/game");
                        setMobileMenuOpen(false);
                      }}
                    >
                      Play Game
                    </Button>
                    
                    {user ? (
                      <>
                        <Button 
                          variant="outline" 
                          onClick={() => {
                            navigate("/wallet");
                            setMobileMenuOpen(false);
                          }}
                        >
                          Wallet
                        </Button>
                        <Button 
                          variant="outline" 
                          onClick={() => {
                            navigate("/history");
                            setMobileMenuOpen(false);
                          }}
                        >
                          History
                        </Button>
                        <Button 
                          variant="outline" 
                          onClick={() => {
                            navigate("/settings");
                            setMobileMenuOpen(false);
                          }}
                        >
                          Settings
                        </Button>
                        <Button 
                          variant="ghost" 
                          onClick={handleLogout}
                        >
                          Logout
                        </Button>
                      </>
                    ) : (
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          navigate("/auth");
                          setMobileMenuOpen(false);
                        }}
                      >
                        Sign In
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
        
        {/* Desktop navigation */}
        <nav className="hidden md:flex items-center space-x-4">
          {user ? (
            <>
              <Card className="flex items-center px-4 py-2">
                <div className="mr-4">
                  <p className="text-sm text-muted-foreground">Balance</p>
                  <p className="font-mono font-medium">${user.balance.toFixed(2)}</p>
                </div>
                <Button size="sm" onClick={() => navigate("/wallet")}>
                  Deposit
                </Button>
              </Card>
              <Button variant="outline" onClick={() => navigate("/game")}>
                Play Game
              </Button>
              <Button variant="ghost" onClick={handleLogout}>
                Logout
              </Button>
            </>
          ) : (
            <Button onClick={() => navigate("/auth")}>
              Sign In
            </Button>
          )}
        </nav>
      </header>
      
      <div className="max-w-4xl mx-auto text-center py-4 sm:py-6 md:py-8">
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-heading font-bold mb-4 md:mb-6">Welcome to CryptoMines</h1>
        <p className="text-lg sm:text-xl mb-8 md:mb-12 text-muted-foreground px-3">
          The most exciting provably fair Mines game online
        </p>
        
        <div className="bg-muted p-4 sm:p-6 md:p-8 rounded-xl mb-8 sm:mb-10 md:mb-12 border border-border mx-3 sm:mx-4 md:mx-0">
          <div className="mb-4 sm:mb-6">
            <span className="text-4xl sm:text-5xl md:text-6xl text-primary">💣</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">Ready to Play?</h2>
          <p className="mb-6 sm:mb-8 text-muted-foreground max-w-xl mx-auto text-sm sm:text-base">
            Uncover tiles, avoid mines, and cash out your winnings! 
            Our provably fair game gives you complete transparency.
          </p>
          
          {user ? (
            <Button 
              size="lg" 
              className="text-lg px-6 sm:px-8"
              onClick={() => navigate("/game")}
            >
              Play Now
            </Button>
          ) : (
            <div className="space-y-4">
              <Button 
                size="lg" 
                className="text-lg px-6 sm:px-8"
                onClick={() => navigate("/auth")}
              >
                Sign In To Play
              </Button>
              <p className="text-sm text-muted-foreground">
                New users get $100 free credits to start playing!
              </p>
            </div>
          )}
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-8 sm:mb-10 md:mb-12 px-3 sm:px-4 md:px-0">
          <div className="bg-background p-4 sm:p-6 md:p-8 rounded-lg border border-border">
            <div className="mb-3 sm:mb-4 text-2xl sm:text-3xl">🔐</div>
            <h3 className="text-lg font-bold mb-2">Provably Fair</h3>
            <p className="text-sm text-muted-foreground">
              Our games use cryptographic verification so you know they're fair
            </p>
          </div>
          
          <div className="bg-background p-4 sm:p-6 md:p-8 rounded-lg border border-border">
            <div className="mb-3 sm:mb-4 text-2xl sm:text-3xl">💰</div>
            <h3 className="text-lg font-bold mb-2">Easy Deposits</h3>
            <p className="text-sm text-muted-foreground">
              Quick and secure payment methods to fund your account
            </p>
          </div>
          
          <div className="bg-background p-4 sm:p-6 md:p-8 rounded-lg border border-border sm:col-span-2 lg:col-span-1">
            <div className="mb-3 sm:mb-4 text-2xl sm:text-3xl">🏆</div>
            <h3 className="text-lg font-bold mb-2">Big Wins</h3>
            <p className="text-sm text-muted-foreground">
              Win up to 10x your bet with strategic gameplay
            </p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row justify-center gap-3 sm:gap-4 px-3 sm:px-4 md:px-0">
          {user ? (
            <>
              <Button 
                variant="secondary" 
                size="lg"
                className="px-6 sm:px-8"
                onClick={() => navigate("/wallet")}
              >
                Manage Wallet
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="px-6 sm:px-8"
                onClick={() => navigate("/game")}
              >
                Play Game
              </Button>
            </>
          ) : (
            <>
              <Button 
                variant="outline" 
                size="lg"
                className="px-6 sm:px-8"
                onClick={() => navigate("/auth")}
              >
                Register Now
              </Button>
              <Button
                variant="secondary"
                size="lg"
                className="px-6 sm:px-8"
                onClick={() => navigate("/auth")}
              >
                Learn More
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
