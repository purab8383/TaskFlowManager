import { useState } from "react";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import DepositForm from "@/components/wallet/deposit-form";
import WithdrawForm from "@/components/wallet/withdraw-form";
import TransactionHistory from "@/components/wallet/transaction-history";
import { WalletProvider } from "@/hooks/use-wallet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowDownCircle, ArrowUpCircle, HelpCircle, CreditCard, Bitcoin } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { Card } from "@/components/ui/card";

export default function WalletPage() {
  const [activeTab, setActiveTab] = useState("deposit");
  const { user } = useAuth();
  
  return (
    <WalletProvider>
      <div className="min-h-screen flex flex-col md:flex-row">
        <Sidebar />
        
        <main className="flex-1 flex flex-col pb-16 md:pb-0">
          <MobileNav />
          
          <div className="flex-1 overflow-auto p-3 sm:p-4 md:p-8">
            {/* Mobile Balance Card - Only visible on small screens */}
            {user && (
              <div className="md:hidden mb-4">
                <Card className="bg-primary/5 p-3 flex justify-between items-center">
                  <div>
                    <p className="text-xs text-muted-foreground">Current Balance</p>
                    <p className="font-mono font-medium text-lg">${user.balance.toFixed(2)}</p>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {activeTab === "deposit" ? "Depositing funds" : "Withdrawing funds"}
                  </div>
                </Card>
              </div>
            )}
            
            <div className="mb-4 sm:mb-6">
              <h2 className="text-xl sm:text-2xl font-heading font-bold text-foreground mb-1 sm:mb-2">Wallet</h2>
              <p className="text-xs sm:text-sm text-muted-foreground">Manage your deposits, withdrawals and view transaction history</p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
              <div className="lg:col-span-2">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4 sm:space-y-6">
                  <TabsList className="w-full grid grid-cols-2">
                    <TabsTrigger value="deposit" className="text-xs sm:text-sm py-1 sm:py-2">
                      <ArrowDownCircle className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                      Deposit
                    </TabsTrigger>
                    <TabsTrigger value="withdraw" className="text-xs sm:text-sm py-1 sm:py-2">
                      <ArrowUpCircle className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                      Withdraw
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="deposit" className="space-y-3 sm:space-y-4">
                    <DepositForm />
                  </TabsContent>
                  
                  <TabsContent value="withdraw" className="space-y-3 sm:space-y-4">
                    <WithdrawForm />
                  </TabsContent>
                </Tabs>
              </div>
              
              {/* Payment Methods and Help - Responsive Layout */}
              <div className="space-y-4 sm:space-y-6">
                <div className="bg-muted rounded-xl p-3 sm:p-4 md:p-5 border border-border">
                  <h3 className="text-base sm:text-lg font-bold mb-2 sm:mb-4">Payment Methods</h3>
                  
                  <div className="space-y-2 sm:space-y-3">
                    <div className="bg-background rounded-md p-2 sm:p-3 flex items-center">
                      <div className="rounded-full bg-primary/10 p-1 sm:p-2 mr-2 sm:mr-3">
                        <CreditCard className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-xs sm:text-sm">Credit/Debit Card</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground">Instant processing</p>
                      </div>
                    </div>
                    
                    <div className="bg-background rounded-md p-2 sm:p-3 flex items-center opacity-60">
                      <div className="rounded-full bg-primary/10 p-1 sm:p-2 mr-2 sm:mr-3">
                        <Bitcoin className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-xs sm:text-sm">Cryptocurrency</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground">Coming soon</p>
                      </div>
                    </div>
                    
                    <div className="bg-background rounded-md p-2 sm:p-3 flex items-center opacity-60">
                      <div className="rounded-full bg-primary/10 p-1 sm:p-2 mr-2 sm:mr-3">
                        <div className="h-4 w-4 sm:h-5 sm:w-5 flex items-center justify-center text-primary">
                          <span className="text-xs sm:text-sm font-bold">P</span>
                        </div>
                      </div>
                      <div>
                        <p className="font-medium text-xs sm:text-sm">PayPal</p>
                        <p className="text-[10px] sm:text-xs text-muted-foreground">Coming soon</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-muted rounded-xl p-3 sm:p-4 md:p-5 border border-border">
                  <h3 className="text-base sm:text-lg font-bold mb-2 sm:mb-4">Need Help?</h3>
                  
                  <div className="space-y-3 sm:space-y-4">
                    <p className="text-xs sm:text-sm text-muted-foreground">
                      If you have any questions about deposits, withdrawals or your account, 
                      please check our FAQ or contact support.
                    </p>
                    
                    <div className="flex space-x-2">
                      <button className="flex-1 py-1 sm:py-2 bg-background rounded-md text-xs sm:text-sm border border-border hover:bg-muted flex items-center justify-center">
                        <HelpCircle className="h-3 w-3 sm:h-4 sm:w-4 mr-1" /> FAQ
                      </button>
                      <button className="flex-1 py-1 sm:py-2 bg-background rounded-md text-xs sm:text-sm border border-border hover:bg-muted flex items-center justify-center">
                        <HelpCircle className="h-3 w-3 sm:h-4 sm:w-4 mr-1" /> Support
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Transaction History - Responsive */}
            <div className="mt-6 sm:mt-8">
              <TransactionHistory />
            </div>
          </div>
        </main>
      </div>
    </WalletProvider>
  );
}
