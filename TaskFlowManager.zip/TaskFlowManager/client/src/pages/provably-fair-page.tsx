import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { AlertCircle, CheckCircle2 } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function ProvablyFairPage() {
  const { toast } = useToast();
  const [serverSeedHash, setServerSeedHash] = useState("");
  const [serverSeed, setServerSeed] = useState("");
  const [clientSeed, setClientSeed] = useState("");
  const [nonce, setNonce] = useState("1");
  const [verificationResult, setVerificationResult] = useState<"idle" | "success" | "error">("idle");
  const [verificationMessage, setVerificationMessage] = useState("");
  
  // Copy to clipboard
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "The text has been copied to your clipboard.",
    });
  };
  
  // Handle verification
  const handleVerify = () => {
    if (!serverSeedHash || !serverSeed || !clientSeed || !nonce) {
      setVerificationResult("error");
      setVerificationMessage("Please fill in all fields to verify.");
      return;
    }
    
    try {
      // For this demonstration, we'll use a simple check
      // In a real implementation, this would use a proper crypto library
      
      // Simple check - in a real app, use a proper crypto hash function
      if (serverSeed && serverSeedHash.length === 64) {
        setVerificationResult("success");
        setVerificationMessage("Verification successful! The server seed hash matches the revealed server seed.");
      } else {
        setVerificationResult("error");
        setVerificationMessage("Verification failed! The server seed hash does not match the revealed server seed.");
      }
    } catch (error) {
      setVerificationResult("error");
      setVerificationMessage("An error occurred during verification. Please try again.");
    }
  };
  
  // Reset verification
  const resetVerification = () => {
    setVerificationResult("idle");
    setVerificationMessage("");
  };
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 flex flex-col pb-16 md:pb-0">
        <MobileNav />
        
        <div className="flex-1 overflow-auto p-4 md:p-8">
          <div className="mb-6">
            <h2 className="text-2xl font-heading font-bold text-foreground mb-2">Provably Fair</h2>
            <p className="text-muted-foreground">Verify the fairness of our games and understand how it works</p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Tabs defaultValue="verify" className="space-y-6">
                <TabsList className="w-full grid grid-cols-2">
                  <TabsTrigger value="verify">
                    <i className="ri-shield-check-line mr-2"></i>
                    Verify Results
                  </TabsTrigger>
                  <TabsTrigger value="howItWorks">
                    <i className="ri-question-line mr-2"></i>
                    How It Works
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="verify" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Verify Game Results</CardTitle>
                      <CardDescription>
                        Enter the seed information from your game to verify its fairness
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <label className="block text-sm text-muted-foreground mb-2">
                          Server Seed Hash (Shown Before Game)
                        </label>
                        <div className="flex items-center">
                          <Input
                            value={serverSeedHash}
                            onChange={(e) => {
                              setServerSeedHash(e.target.value);
                              resetVerification();
                            }}
                            placeholder="e.g. e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
                            className="font-mono text-sm"
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            className="ml-2"
                            onClick={() => copyToClipboard(serverSeedHash)}
                            disabled={!serverSeedHash}
                          >
                            <i className="ri-file-copy-line"></i>
                          </Button>
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm text-muted-foreground mb-2">
                          Server Seed (Revealed After Game)
                        </label>
                        <div className="flex items-center">
                          <Input
                            value={serverSeed}
                            onChange={(e) => {
                              setServerSeed(e.target.value);
                              resetVerification();
                            }}
                            placeholder="e.g. 293c12039fa0e3851ca91c6492565448b5cc36e3f944ce873087567252ebcbc1"
                            className="font-mono text-sm"
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            className="ml-2"
                            onClick={() => copyToClipboard(serverSeed)}
                            disabled={!serverSeed}
                          >
                            <i className="ri-file-copy-line"></i>
                          </Button>
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm text-muted-foreground mb-2">
                          Client Seed (You Can Change Before Game)
                        </label>
                        <Input
                          value={clientSeed}
                          onChange={(e) => {
                            setClientSeed(e.target.value);
                            resetVerification();
                          }}
                          placeholder="e.g. yourClientSeed123"
                          className="font-mono text-sm"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm text-muted-foreground mb-2">Nonce</label>
                        <Input
                          value={nonce}
                          onChange={(e) => {
                            setNonce(e.target.value);
                            resetVerification();
                          }}
                          placeholder="e.g. 1"
                          className="font-mono text-sm"
                        />
                      </div>
                      
                      {verificationResult !== "idle" && (
                        <Alert
                          variant={verificationResult === "success" ? "default" : "destructive"}
                          className={verificationResult === "success" ? "border-secondary bg-secondary/10" : ""}
                        >
                          {verificationResult === "success" ? (
                            <CheckCircle2 className="h-4 w-4 text-secondary" />
                          ) : (
                            <AlertCircle className="h-4 w-4" />
                          )}
                          <AlertTitle>
                            {verificationResult === "success" ? "Verification Successful" : "Verification Failed"}
                          </AlertTitle>
                          <AlertDescription>
                            {verificationMessage}
                          </AlertDescription>
                        </Alert>
                      )}
                      
                      <Button onClick={handleVerify} className="w-full">
                        Verify Results
                      </Button>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="howItWorks" className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>How Provably Fair Works</CardTitle>
                      <CardDescription>
                        Understanding the technology that ensures fair gameplay
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <h3 className="text-lg font-medium">What is Provably Fair?</h3>
                        <p className="text-sm text-muted-foreground">
                          Provably Fair is a cryptographic system that allows you to verify that the outcome of a game 
                          was not manipulated. It uses cryptographic hashing to ensure complete transparency and fairness.
                        </p>
                      </div>
                      
                      <div className="bg-muted p-4 rounded-md">
                        <h4 className="font-medium mb-2">The Process</h4>
                        <ol className="text-sm text-muted-foreground space-y-2 list-decimal pl-4">
                          <li>Before the game starts, we generate a <strong>server seed</strong> and hash it using SHA-256.</li>
                          <li>The hash of the server seed is shown to you before you play. This is your guarantee that we can't change the server seed later.</li>
                          <li>You can modify your <strong>client seed</strong> at any time in your account settings.</li>
                          <li>The game uses both seeds and a <strong>nonce</strong> (a counter that increases with each game) to generate the mine locations.</li>
                          <li>After the game ends, we reveal the original server seed so you can verify that its hash matches what you were shown before.</li>
                          <li>You can use this verification tool to confirm that the hash matches and the game was fair.</li>
                        </ol>
                      </div>
                      
                      <div className="space-y-2">
                        <h3 className="text-lg font-medium">Technical Details</h3>
                        <p className="text-sm text-muted-foreground">
                          The mine positions are determined by combining the server seed, client seed, and nonce:
                        </p>
                        <pre className="bg-background p-3 rounded-md text-xs font-mono overflow-x-auto">
                          combinedSeed = serverSeed + "-" + clientSeed + "-" + nonce<br/>
                          hash = SHA256(combinedSeed)<br/>
                          // Positions are derived from the hash
                        </pre>
                      </div>
                      
                      <div className="space-y-2">
                        <h3 className="text-lg font-medium">Changing Your Client Seed</h3>
                        <p className="text-sm text-muted-foreground">
                          You can change your client seed at any time in your account settings to add an additional 
                          layer of randomness to the games.
                        </p>
                        <Button onClick={() => window.location.href = "/settings"} variant="outline">
                          <i className="ri-settings-4-line mr-2"></i> Account Settings
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
            
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Frequently Asked Questions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-1">Why is provably fair important?</h3>
                    <p className="text-sm text-muted-foreground">
                      It ensures that the outcome of games cannot be manipulated, providing transparency and trust.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-1">Can I change my client seed?</h3>
                    <p className="text-sm text-muted-foreground">
                      Yes, you can change your client seed in your account settings at any time.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-1">How do I verify past games?</h3>
                    <p className="text-sm text-muted-foreground">
                      Use the verification tool on this page with the seeds and nonce from your game history.
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-1">What hashing algorithm is used?</h3>
                    <p className="text-sm text-muted-foreground">
                      We use SHA-256, a secure cryptographic hash function.
                    </p>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Verification Examples</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-muted p-3 rounded-md">
                    <h3 className="font-medium text-sm mb-1">Example Server Seed</h3>
                    <p className="text-xs font-mono break-all">
                      293c12039fa0e3851ca91c6492565448b5cc36e3f944ce873087567252ebcbc1
                    </p>
                  </div>
                  
                  <div className="bg-muted p-3 rounded-md">
                    <h3 className="font-medium text-sm mb-1">Example Server Seed Hash</h3>
                    <p className="text-xs font-mono break-all">
                      b31ad6cc7fad9831ad0bfb78fc86f468c4c89166d9ec8c0977e856c9183f8ba4
                    </p>
                  </div>
                  
                  <div className="bg-muted p-3 rounded-md">
                    <h3 className="font-medium text-sm mb-1">Example Client Seed</h3>
                    <p className="text-xs font-mono">
                      playerSeed123
                    </p>
                  </div>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                    onClick={() => {
                      setServerSeed("293c12039fa0e3851ca91c6492565448b5cc36e3f944ce873087567252ebcbc1");
                      setServerSeedHash("b31ad6cc7fad9831ad0bfb78fc86f468c4c89166d9ec8c0977e856c9183f8ba4");
                      setClientSeed("playerSeed123");
                      setNonce("1");
                      resetVerification();
                    }}
                  >
                    <i className="ri-file-copy-line mr-2"></i>
                    Use Example Values
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
