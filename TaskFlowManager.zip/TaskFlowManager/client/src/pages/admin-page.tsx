import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import Sidebar from "@/components/layout/sidebar";
import MobileNav from "@/components/layout/mobile-nav";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { User, Transaction } from "@shared/schema";
import { Redirect } from "wouter";
import { Loader2 } from "lucide-react";

export default function AdminPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Transaction | null>(null);
  const [showApproveDialog, setShowApproveDialog] = useState(false);
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  
  // Redirect if not admin
  if (user && !user.isAdmin) {
    return <Redirect to="/" />;
  }
  
  // Get all users
  const {
    data: users = [],
    isLoading: isLoadingUsers,
  } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
    staleTime: 30000, // 30 seconds
  });
  
  // Get pending withdrawals
  const {
    data: withdrawals = [],
    isLoading: isLoadingWithdrawals,
  } = useQuery<Transaction[]>({
    queryKey: ["/api/admin/withdrawals"],
    staleTime: 10000, // 10 seconds
  });
  
  // Approve withdrawal mutation
  const approveMutation = useMutation({
    mutationFn: async (transactionId: number) => {
      const res = await apiRequest("POST", `/api/admin/withdrawals/${transactionId}/approve`, {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/withdrawals"] });
      toast({
        title: "Withdrawal Approved",
        description: "The withdrawal request has been approved successfully.",
      });
      setShowApproveDialog(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Approval Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Reject withdrawal mutation
  const rejectMutation = useMutation({
    mutationFn: async ({ transactionId, userId }: { transactionId: number; userId: number }) => {
      const res = await apiRequest("POST", `/api/admin/withdrawals/${transactionId}/reject`, { userId });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/withdrawals"] });
      toast({
        title: "Withdrawal Rejected",
        description: "The withdrawal request has been rejected and funds returned to the user.",
      });
      setShowRejectDialog(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Rejection Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Format currency
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(Math.abs(amount));
  };
  
  // Format date
  const formatDateTime = (timestamp: Date) => {
    return new Date(timestamp).toLocaleString();
  };
  
  // Handle approve withdrawal
  const handleApproveWithdrawal = (withdrawal: Transaction) => {
    setSelectedWithdrawal(withdrawal);
    setShowApproveDialog(true);
  };
  
  // Handle reject withdrawal
  const handleRejectWithdrawal = (withdrawal: Transaction) => {
    setSelectedWithdrawal(withdrawal);
    setShowRejectDialog(true);
  };
  
  // Submit approve
  const submitApprove = () => {
    if (selectedWithdrawal) {
      approveMutation.mutate(selectedWithdrawal.id);
    }
  };
  
  // Submit reject
  const submitReject = () => {
    if (selectedWithdrawal) {
      rejectMutation.mutate({
        transactionId: selectedWithdrawal.id,
        userId: selectedWithdrawal.userId,
      });
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 flex flex-col pb-16 md:pb-0">
        <MobileNav />
        
        <div className="flex-1 overflow-auto p-4 md:p-8">
          <div className="mb-6">
            <h2 className="text-2xl font-heading font-bold text-foreground mb-2">Admin Dashboard</h2>
            <p className="text-muted-foreground">Manage users, withdrawals, and system settings</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="ri-user-line text-xl text-primary"></i>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Total Users</p>
                    <p className="text-2xl font-bold">
                      {isLoadingUsers ? <Skeleton className="h-8 w-16" /> : users.length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="ri-wallet-3-line text-xl text-primary"></i>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Pending Withdrawals</p>
                    <p className="text-2xl font-bold">
                      {isLoadingWithdrawals ? <Skeleton className="h-8 w-16" /> : withdrawals.length}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="ri-gamepad-line text-xl text-primary"></i>
                  </div>
                  <div>
                    <p className="text-muted-foreground text-sm">Active Games</p>
                    <p className="text-2xl font-bold">
                      {isLoadingUsers ? <Skeleton className="h-8 w-16" /> : "0"}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="withdrawals" className="space-y-6">
            <TabsList>
              <TabsTrigger value="withdrawals">Pending Withdrawals</TabsTrigger>
              <TabsTrigger value="users">User Management</TabsTrigger>
              <TabsTrigger value="settings">System Settings</TabsTrigger>
            </TabsList>
            
            <TabsContent value="withdrawals">
              <Card>
                <CardHeader>
                  <CardTitle>Pending Withdrawal Requests</CardTitle>
                  <CardDescription>
                    Review and process pending withdrawal requests
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingWithdrawals ? (
                    <div className="space-y-4">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="flex items-center justify-between border-b border-border pb-4">
                          <div className="flex items-center">
                            <Skeleton className="h-12 w-12 rounded-full" />
                            <div className="ml-4">
                              <Skeleton className="h-4 w-24 mb-2" />
                              <Skeleton className="h-3 w-32" />
                            </div>
                          </div>
                          <div>
                            <Skeleton className="h-6 w-20" />
                          </div>
                          <div>
                            <Skeleton className="h-9 w-20 mr-2 inline-block" />
                            <Skeleton className="h-9 w-20 inline-block" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : withdrawals.length === 0 ? (
                    <div className="text-center py-12">
                      <div className="text-muted-foreground mb-2">
                        <i className="ri-checkbox-circle-line text-5xl"></i>
                      </div>
                      <h3 className="text-xl font-medium mb-2">No Pending Withdrawals</h3>
                      <p className="text-muted-foreground mb-4">
                        There are no withdrawal requests to process at this time.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {withdrawals.map((withdrawal) => (
                        <div key={withdrawal.id} className="flex flex-wrap md:items-center justify-between border-b border-border pb-4 gap-4">
                          <div className="flex items-center">
                            <Avatar className="h-12 w-12">
                              <AvatarFallback>
                                {String(withdrawal.userId).substring(0, 2)}
                              </AvatarFallback>
                            </Avatar>
                            <div className="ml-4">
                              <p className="font-medium">User #{withdrawal.userId}</p>
                              <p className="text-sm text-muted-foreground">
                                {formatDateTime(withdrawal.createdAt)}
                              </p>
                            </div>
                          </div>
                          <div>
                            <Badge className="bg-yellow-500">Pending</Badge>
                            <p className="text-xl font-mono font-medium mt-1">
                              {formatCurrency(withdrawal.amount)}
                            </p>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              className="border-green-500 text-green-500 hover:bg-green-500 hover:text-white"
                              onClick={() => handleApproveWithdrawal(withdrawal)}
                            >
                              Approve
                            </Button>
                            <Button
                              variant="outline"
                              className="border-destructive text-destructive hover:bg-destructive hover:text-white"
                              onClick={() => handleRejectWithdrawal(withdrawal)}
                            >
                              Reject
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="users">
              <Card>
                <CardHeader>
                  <CardTitle>User Management</CardTitle>
                  <CardDescription>
                    View and manage user accounts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {isLoadingUsers ? (
                    <div className="space-y-4">
                      {[1, 2, 3, 4].map((i) => (
                        <div key={i} className="flex items-center justify-between border-b border-border pb-4">
                          <div className="flex items-center">
                            <Skeleton className="h-12 w-12 rounded-full" />
                            <div className="ml-4">
                              <Skeleton className="h-4 w-24 mb-2" />
                              <Skeleton className="h-3 w-32" />
                            </div>
                          </div>
                          <div>
                            <Skeleton className="h-4 w-16" />
                          </div>
                          <div>
                            <Skeleton className="h-9 w-20" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : users.length === 0 ? (
                    <div className="text-center py-12">
                      <div className="text-muted-foreground mb-2">
                        <i className="ri-user-search-line text-5xl"></i>
                      </div>
                      <h3 className="text-xl font-medium mb-2">No Users Found</h3>
                      <p className="text-muted-foreground mb-4">
                        There are no users registered in the system.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="overflow-x-auto">
                        <table className="w-full border-collapse">
                          <thead>
                            <tr className="text-left border-b border-border">
                              <th className="pb-2 font-medium">User</th>
                              <th className="pb-2 font-medium">Email</th>
                              <th className="pb-2 font-medium">Balance</th>
                              <th className="pb-2 font-medium">Role</th>
                              <th className="pb-2 font-medium">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {users.map((user) => (
                              <tr key={user.id} className="border-b border-border">
                                <td className="py-3">
                                  <div className="flex items-center">
                                    <Avatar className="h-8 w-8 mr-2">
                                      <AvatarFallback>
                                        {user.username.substring(0, 2).toUpperCase()}
                                      </AvatarFallback>
                                    </Avatar>
                                    <span>{user.username}</span>
                                  </div>
                                </td>
                                <td className="py-3 text-muted-foreground">
                                  {user.email}
                                </td>
                                <td className="py-3 font-mono">
                                  ${user.balance.toFixed(2)}
                                </td>
                                <td className="py-3">
                                  {user.isAdmin ? (
                                    <Badge className="bg-primary">Admin</Badge>
                                  ) : (
                                    <Badge variant="outline">User</Badge>
                                  )}
                                </td>
                                <td className="py-3">
                                  <Button variant="outline" size="sm">
                                    View
                                  </Button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>System Settings</CardTitle>
                  <CardDescription>
                    Configure global system settings
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Game Settings</h3>
                      <div className="space-y-4">
                        <div className="flex flex-col space-y-2">
                          <label className="text-sm font-medium">House Edge (%)</label>
                          <div className="flex items-center">
                            <input
                              type="number"
                              min="1"
                              max="10"
                              defaultValue="3"
                              className="w-24 rounded-md border border-border bg-background px-3 py-2 text-sm"
                            />
                            <span className="ml-2 text-muted-foreground">
                              Recommended: 1-5%
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex flex-col space-y-2">
                          <label className="text-sm font-medium">Max Bet Amount ($)</label>
                          <div className="flex items-center">
                            <input
                              type="number"
                              min="100"
                              defaultValue="1000"
                              className="w-24 rounded-md border border-border bg-background px-3 py-2 text-sm"
                            />
                          </div>
                        </div>
                        
                        <div className="flex flex-col space-y-2">
                          <label className="text-sm font-medium">Min Bet Amount ($)</label>
                          <div className="flex items-center">
                            <input
                              type="number"
                              min="1"
                              defaultValue="1"
                              className="w-24 rounded-md border border-border bg-background px-3 py-2 text-sm"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-medium mb-4">Withdrawal Settings</h3>
                      <div className="space-y-4">
                        <div className="flex flex-col space-y-2">
                          <label className="text-sm font-medium">Min Withdrawal Amount ($)</label>
                          <div className="flex items-center">
                            <input
                              type="number"
                              min="5"
                              defaultValue="10"
                              className="w-24 rounded-md border border-border bg-background px-3 py-2 text-sm"
                            />
                          </div>
                        </div>
                        
                        <div className="flex flex-col space-y-2">
                          <label className="text-sm font-medium">Max Withdrawal Amount ($)</label>
                          <div className="flex items-center">
                            <input
                              type="number"
                              min="100"
                              defaultValue="1000"
                              className="w-24 rounded-md border border-border bg-background px-3 py-2 text-sm"
                            />
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id="auto-approve"
                            className="rounded border-border bg-background"
                          />
                          <label htmlFor="auto-approve" className="text-sm font-medium">
                            Auto-approve withdrawals under $100
                          </label>
                        </div>
                      </div>
                    </div>
                    
                    <Button className="w-full md:w-auto">
                      Save Settings
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      {/* Approve Withdrawal Dialog */}
      <Dialog open={showApproveDialog} onOpenChange={setShowApproveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Approve Withdrawal</DialogTitle>
            <DialogDescription>
              Are you sure you want to approve this withdrawal request?
            </DialogDescription>
          </DialogHeader>
          
          {selectedWithdrawal && (
            <div className="py-4">
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">User ID:</span>
                <span className="font-medium">#{selectedWithdrawal.userId}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Amount:</span>
                <span className="font-medium font-mono">{formatCurrency(selectedWithdrawal.amount)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Requested:</span>
                <span className="font-medium">{formatDateTime(selectedWithdrawal.createdAt)}</span>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowApproveDialog(false)}
              disabled={approveMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              onClick={submitApprove}
              disabled={approveMutation.isPending}
              className="bg-green-500 hover:bg-green-600"
            >
              {approveMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                </>
              ) : (
                "Approve Withdrawal"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Reject Withdrawal Dialog */}
      <AlertDialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reject Withdrawal</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to reject this withdrawal request? The funds will be returned to the user's account.
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          {selectedWithdrawal && (
            <div className="py-2">
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">User ID:</span>
                <span className="font-medium">#{selectedWithdrawal.userId}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-muted-foreground">Amount:</span>
                <span className="font-medium font-mono">{formatCurrency(selectedWithdrawal.amount)}</span>
              </div>
            </div>
          )}
          
          <AlertDialogFooter>
            <AlertDialogCancel disabled={rejectMutation.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                submitReject();
              }}
              disabled={rejectMutation.isPending}
              className="bg-destructive hover:bg-destructive/90"
            >
              {rejectMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                </>
              ) : (
                "Reject Withdrawal"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
