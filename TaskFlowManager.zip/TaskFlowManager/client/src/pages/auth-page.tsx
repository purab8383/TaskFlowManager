import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function AuthPage() {
  const [, navigate] = useLocation();
  const { user, loginMutation, registerMutation, isLoading } = useAuth();
  const { toast } = useToast();
  
  // Form state
  const [loginForm, setLoginForm] = useState({
    username: "",
    password: ""
  });
  
  const [registerForm, setRegisterForm] = useState({
    username: "",
    email: "",
    password: "",
    confirmPassword: ""
  });

  // Error states
  const [loginError, setLoginError] = useState("");
  const [registerError, setRegisterError] = useState("");
  
  // If user is already logged in, redirect to home
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);
  
  // Handle login form submission
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    
    if (!loginForm.username || !loginForm.password) {
      setLoginError("Please enter both username and password");
      return;
    }
    
    loginMutation.mutate(loginForm, {
      onSuccess: () => {
        toast({
          title: "Login successful",
          description: "Welcome back to CryptoMines!",
        });
        navigate("/");
      },
      onError: (error) => {
        setLoginError(error.message);
      }
    });
  };
  
  // Handle registration form submission
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setRegisterError("");
    
    // Validate the form
    if (!registerForm.username || !registerForm.email || !registerForm.password) {
      setRegisterError("Please fill in all required fields");
      return;
    }
    
    if (registerForm.password !== registerForm.confirmPassword) {
      setRegisterError("Passwords do not match");
      return;
    }
    
    // Submit registration
    registerMutation.mutate({
      username: registerForm.username,
      email: registerForm.email,
      password: registerForm.password,
      balance: 100, // Give new users some starting balance
      clientSeed: Math.random().toString(36).substring(2, 15), // Generate a random client seed
      clientSeedHash: "" // Will be set by the server
    }, {
      onSuccess: () => {
        toast({
          title: "Registration successful",
          description: "Your account has been created with a $100 balance!",
        });
        navigate("/");
      },
      onError: (error) => {
        setRegisterError(error.message);
      }
    });
  };
  
  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Hero Section - Hidden on small screens, visible on large screens */}
      <div className="bg-gradient-to-br from-primary to-primary/70 hidden lg:flex lg:w-1/2 p-4 sm:p-6 md:p-8 items-center justify-center">
        <div className="max-w-md text-white">
          <div className="mb-4 sm:mb-6 flex items-center">
            <div className="bg-white/20 rounded-lg p-2 sm:p-3 mr-3 sm:mr-4">
              <span className="text-2xl sm:text-3xl">💣</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-heading font-bold">CryptoMines</h1>
          </div>
          
          <h2 className="text-xl sm:text-2xl font-bold mb-3 sm:mb-4">Provably Fair Mines Game</h2>
          <p className="mb-4 sm:mb-6 text-white/90 text-sm sm:text-base">
            Play the exciting Mines game with real money! Uncover tiles, avoid mines, and cash out your winnings. 
            Our provably fair system ensures complete transparency and fairness.
          </p>
          
          <div className="space-y-3 sm:space-y-4">
            <div className="flex items-center">
              <span className="mr-2">✓</span>
              <span className="text-sm sm:text-base">Provably fair gameplay</span>
            </div>
            <div className="flex items-center">
              <span className="mr-2">✓</span>
              <span className="text-sm sm:text-base">Easy deposits and withdrawals</span>
            </div>
            <div className="flex items-center">
              <span className="mr-2">✓</span>
              <span className="text-sm sm:text-base">Win up to 10x your bet</span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Mobile Header - Only visible on small screens */}
      <div className="bg-gradient-to-br from-primary to-primary/70 p-4 flex items-center justify-center lg:hidden">
        <div className="flex items-center">
          <div className="bg-white/20 rounded-lg p-2 mr-3">
            <span className="text-2xl text-white">💣</span>
          </div>
          <div>
            <h1 className="text-2xl font-heading font-bold text-white">CryptoMines</h1>
            <p className="text-xs text-white/90">Provably Fair Mines Game</p>
          </div>
        </div>
      </div>
      
      {/* Auth Forms */}
      <div className="lg:w-1/2 p-3 sm:p-4 md:p-6 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="text-xl sm:text-2xl">Welcome to CryptoMines</CardTitle>
            <CardDescription className="text-sm">
              Sign in to your account or create a new one to start playing
            </CardDescription>
            <button 
              onClick={() => navigate("/")} 
              className="mt-2 text-xs sm:text-sm text-primary hover:underline"
            >
              ← Back to Home
            </button>
          </CardHeader>
          <CardContent className="p-4 sm:p-6 pt-0 sm:pt-0">
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-4 sm:mb-6">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
              
              <TabsContent value="login">
                <form onSubmit={handleLogin}>
                  {loginError && (
                    <Alert variant="destructive" className="mb-3 sm:mb-4 text-xs sm:text-sm">
                      <AlertDescription>{loginError}</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-3 sm:space-y-4">
                    <div className="space-y-1 sm:space-y-2">
                      <Label htmlFor="username" className="text-xs sm:text-sm">Username</Label>
                      <Input 
                        id="username"
                        value={loginForm.username}
                        onChange={(e) => setLoginForm({...loginForm, username: e.target.value})}
                        placeholder="Enter your username"
                        className="h-9 sm:h-10 text-sm"
                      />
                    </div>
                    <div className="space-y-1 sm:space-y-2">
                      <Label htmlFor="password" className="text-xs sm:text-sm">Password</Label>
                      <Input 
                        id="password"
                        type="password"
                        value={loginForm.password}
                        onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                        placeholder="Enter your password"
                        className="h-9 sm:h-10 text-sm"
                      />
                    </div>
                    <Button 
                      type="submit"
                      className="w-full h-9 sm:h-10 text-sm"
                      disabled={isLoading}
                    >
                      {isLoading ? "Logging in..." : "Login"}
                    </Button>
                  </div>
                </form>
              </TabsContent>
              
              <TabsContent value="register">
                <form onSubmit={handleRegister}>
                  {registerError && (
                    <Alert variant="destructive" className="mb-3 sm:mb-4 text-xs sm:text-sm">
                      <AlertDescription>{registerError}</AlertDescription>
                    </Alert>
                  )}
                  
                  <div className="space-y-3 sm:space-y-4">
                    <div className="space-y-1 sm:space-y-2">
                      <Label htmlFor="reg-username" className="text-xs sm:text-sm">Username</Label>
                      <Input 
                        id="reg-username"
                        value={registerForm.username}
                        onChange={(e) => setRegisterForm({...registerForm, username: e.target.value})}
                        placeholder="Choose a username"
                        className="h-9 sm:h-10 text-sm"
                      />
                    </div>
                    <div className="space-y-1 sm:space-y-2">
                      <Label htmlFor="email" className="text-xs sm:text-sm">Email</Label>
                      <Input 
                        id="email"
                        type="email"
                        value={registerForm.email}
                        onChange={(e) => setRegisterForm({...registerForm, email: e.target.value})}
                        placeholder="Enter your email"
                        className="h-9 sm:h-10 text-sm"
                      />
                    </div>
                    <div className="space-y-1 sm:space-y-2">
                      <Label htmlFor="reg-password" className="text-xs sm:text-sm">Password</Label>
                      <Input 
                        id="reg-password"
                        type="password"
                        value={registerForm.password}
                        onChange={(e) => setRegisterForm({...registerForm, password: e.target.value})}
                        placeholder="Create a password"
                        className="h-9 sm:h-10 text-sm" 
                      />
                    </div>
                    <div className="space-y-1 sm:space-y-2">
                      <Label htmlFor="confirm-password" className="text-xs sm:text-sm">Confirm Password</Label>
                      <Input 
                        id="confirm-password"
                        type="password"
                        value={registerForm.confirmPassword}
                        onChange={(e) => setRegisterForm({...registerForm, confirmPassword: e.target.value})}
                        placeholder="Confirm your password"
                        className="h-9 sm:h-10 text-sm"
                      />
                    </div>
                    <Button 
                      type="submit"
                      className="w-full h-9 sm:h-10 text-sm"
                      disabled={isLoading}
                    >
                      {isLoading ? "Creating Account..." : "Create Account"}
                    </Button>
                  </div>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-center p-4 sm:p-6 text-center">
            <p className="text-[10px] sm:text-xs text-muted-foreground px-2">
              By registering, you agree to our Terms of Service and Privacy Policy
            </p>
          </CardFooter>
        </Card>
      </div>
      
      {/* Mobile Feature List - Only visible on small screens */}
      <div className="p-4 flex flex-col items-center lg:hidden mb-6">
        <h2 className="text-base font-bold mb-3 text-center">Why Choose CryptoMines?</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-md">
          <div className="bg-muted rounded-lg p-3 flex flex-col items-center">
            <span className="text-xl mb-2">🔐</span>
            <h3 className="text-sm font-bold mb-1">Provably Fair</h3>
            <p className="text-xs text-muted-foreground text-center">Cryptographic verification system</p>
          </div>
          <div className="bg-muted rounded-lg p-3 flex flex-col items-center">
            <span className="text-xl mb-2">💰</span>
            <h3 className="text-sm font-bold mb-1">Start With $100</h3>
            <p className="text-xs text-muted-foreground text-center">Free credits for new players</p>
          </div>
          <div className="bg-muted rounded-lg p-3 flex flex-col items-center">
            <span className="text-xl mb-2">🏆</span>
            <h3 className="text-sm font-bold mb-1">Win Big</h3>
            <p className="text-xs text-muted-foreground text-center">Up to 10x multiplier on bets</p>
          </div>
        </div>
      </div>
    </div>
  );
}
