import { createContext, useState, useContext, ReactNode, useEffect, useCallback } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Types
interface GameContextType {
  startGame: (betAmount: number, mineCount: number) => void;
  clickTile: (tileIndex: number) => void;
  cashout: () => void;
  isGameActive: boolean;
  currentGameId: number | null;
  isLoading: boolean;
  error: string | null;
  tiles: Array<TileState>;
  mines: Array<number>;
  revealedTiles: Array<number>;
  betAmount: number;
  mineCount: number;
  currentMultiplier: number;
  potentialWin: number;
  serverSeedHash: string;
  clearError: () => void;
}

export interface TileState {
  index: number;
  revealed: boolean;
  isMine: boolean;
  multiplier: number | null;
}

interface GameState {
  id: number;
  betAmount: number;
  mineCount: number;
  serverSeedHash: string;
  status: string;
  result: {
    grid: Array<number>;
    mines: Array<number>;
    revealed: Array<number>;
    multiplier: number;
    cashout: number | null;
  };
}

const GameContext = createContext<GameContextType | null>(null);

export function GameProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [currentGameId, setCurrentGameId] = useState<number | null>(null);
  const [isGameActive, setIsGameActive] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Game state
  const [tiles, setTiles] = useState<Array<TileState>>(Array(25).fill(0).map((_, i) => ({
    index: i,
    revealed: false,
    isMine: false,
    multiplier: null
  })));
  const [mines, setMines] = useState<Array<number>>([]);
  const [revealedTiles, setRevealedTiles] = useState<Array<number>>([]);
  const [betAmount, setBetAmount] = useState(0);
  const [mineCount, setMineCount] = useState(0);
  const [currentMultiplier, setCurrentMultiplier] = useState(1);
  const [serverSeedHash, setServerSeedHash] = useState("");

  // Query for current game if it exists
  const { isLoading: isGameLoading, refetch: refetchGame, data: gameData } = useQuery({
    queryKey: ["/api/games", currentGameId],
    enabled: !!currentGameId && isGameActive,
    queryFn: async ({ queryKey }) => {
      const gameId = queryKey[1];
      const res = await fetch(`/api/games/${gameId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch game");
      return res.json();
    },
  });
  
  // Handle game data updates
  useEffect(() => {
    if (gameData) {
      updateGameState(gameData);
    }
  }, [gameData]);
  
  // Handle game query errors
  const onGameQueryError = useCallback((err: Error) => {
    setError(err.message);
    toast({
      title: "Game Error",
      description: err.message,
      variant: "destructive",
    });
  }, [toast]);

  // Start game mutation
  const startGameMutation = useMutation({
    mutationFn: async ({ betAmount, mineCount }: { betAmount: number, mineCount: number }) => {
      const res = await apiRequest("POST", "/api/games", { betAmount, mineCount });
      return res.json();
    },
    onSuccess: (data) => {
      setCurrentGameId(data.id);
      setBetAmount(data.betAmount);
      setMineCount(data.mineCount);
      setServerSeedHash(data.serverSeedHash);
      setIsGameActive(true);
      setRevealedTiles([]);
      setMines([]);
      setCurrentMultiplier(1);
      
      // Reset all tiles
      setTiles(Array(25).fill(0).map((_, i) => ({
        index: i,
        revealed: false,
        isMine: false,
        multiplier: null
      })));
      
      // Aggressively refresh user data to update the balance in UI
      queryClient.invalidateQueries({ queryKey: ["/api/user"] }); // Refresh user balance
      
      // Force a re-fetch of user data immediately after invalidation
      setTimeout(() => {
        queryClient.fetchQuery({ queryKey: ["/api/user"] });
      }, 100);
      
      toast({
        title: "Game Started",
        description: `Bet placed: $${data.betAmount}. Good luck!`,
      });
    },
    onError: (err: Error) => {
      setError(err.message);
      toast({
        title: "Failed to Start Game",
        description: err.message,
        variant: "destructive",
      });
    }
  });

  // Click tile mutation
  const clickTileMutation = useMutation({
    mutationFn: async ({ gameId, tileIndex }: { gameId: number, tileIndex: number }) => {
      const res = await apiRequest("POST", `/api/games/${gameId}/tiles/${tileIndex}`, {});
      return res.json();
    },
    onSuccess: (data: GameState) => {
      updateGameState(data);
      
      // Check if game ended by hitting a mine
      if (data.status === 'lost') {
        setIsGameActive(false);
        toast({
          title: "Game Over",
          description: "You hit a mine! Better luck next time.",
          variant: "destructive",
        });
        
        // Aggressively refresh user data to update the balance in UI
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
        queryClient.invalidateQueries({ queryKey: ["/api/games"] });
        
        // Force a re-fetch of user data immediately after invalidation
        setTimeout(() => {
          queryClient.fetchQuery({ queryKey: ["/api/user"] });
        }, 100);
      }
    },
    onError: (err: Error) => {
      setError(err.message);
      toast({
        title: "Error",
        description: err.message,
        variant: "destructive",
      });
    }
  });

  // Cashout mutation
  const cashoutMutation = useMutation({
    mutationFn: async (gameId: number) => {
      const res = await apiRequest("POST", `/api/games/${gameId}/cashout`, {});
      return res.json();
    },
    onSuccess: (data: GameState) => {
      updateGameState(data);
      setIsGameActive(false);
      
      const winAmount = data.result.cashout;
      
      toast({
        title: "Cash Out Successful",
        description: `You won $${winAmount?.toFixed(2)}!`,
      });
      
      // Aggressively refresh user data to update the balance in UI
      queryClient.invalidateQueries({ queryKey: ["/api/user"] }); // Refresh user balance
      queryClient.invalidateQueries({ queryKey: ["/api/games"] }); // Refresh game list
      
      // Force a re-fetch of user data immediately after invalidation
      setTimeout(() => {
        queryClient.fetchQuery({ queryKey: ["/api/user"] });
      }, 100);
    },
    onError: (err: Error) => {
      setError(err.message);
      toast({
        title: "Cash Out Failed",
        description: err.message,
        variant: "destructive",
      });
    }
  });

  const updateGameState = (gameData: GameState) => {
    if (!gameData) return;
    
    // Update revealed tiles
    setRevealedTiles(gameData.result.revealed);
    
    // Update multiplier
    setCurrentMultiplier(gameData.result.multiplier);
    
    // Update mines if game is over
    if (gameData.status === 'lost' || gameData.status === 'won') {
      setMines(gameData.result.mines);
    }
    
    // Update tiles
    setTiles(prevTiles => {
      const newTiles = [...prevTiles];
      
      // Mark revealed tiles
      gameData.result.revealed.forEach(index => {
        newTiles[index] = {
          ...newTiles[index],
          revealed: true,
          multiplier: gameData.result.grid[index] || null
        };
      });
      
      // Mark mines if they are revealed
      if (gameData.status === 'lost' || gameData.status === 'won') {
        gameData.result.mines.forEach(index => {
          newTiles[index] = {
            ...newTiles[index],
            isMine: true
          };
        });
      }
      
      return newTiles;
    });
  };

  // Game actions
  const startGame = (betAmount: number, mineCount: number) => {
    startGameMutation.mutate({ betAmount, mineCount });
  };

  const clickTile = (tileIndex: number) => {
    if (!isGameActive || !currentGameId) return;
    if (revealedTiles.includes(tileIndex)) return;
    
    clickTileMutation.mutate({ gameId: currentGameId, tileIndex });
  };

  const cashout = () => {
    if (!isGameActive || !currentGameId) return;
    if (revealedTiles.length === 0) return;
    
    cashoutMutation.mutate(currentGameId);
  };

  const clearError = () => {
    setError(null);
  };

  const isLoading = startGameMutation.isPending || clickTileMutation.isPending || cashoutMutation.isPending || isGameLoading;
  const potentialWin = betAmount * currentMultiplier;

  return (
    <GameContext.Provider
      value={{
        startGame,
        clickTile,
        cashout,
        isGameActive,
        currentGameId,
        isLoading,
        error,
        tiles,
        mines,
        revealedTiles,
        betAmount,
        mineCount,
        currentMultiplier,
        potentialWin,
        serverSeedHash,
        clearError,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error("useGame must be used within a GameProvider");
  }
  return context;
}
