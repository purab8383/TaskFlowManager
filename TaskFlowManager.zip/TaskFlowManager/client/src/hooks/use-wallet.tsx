import { createContext, ReactNode, useContext } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Transaction as TransactionType } from "@shared/schema";

interface WalletContextType {
  transactions: TransactionType[];
  isLoading: boolean;
  deposit: (amount: number) => void;
  withdraw: (amount: number) => void;
  isTransactionPending: boolean;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  
  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ["/api/wallet/transactions"],
    staleTime: 60000, // 1 minute
  });
  
  const depositMutation = useMutation({
    mutationFn: async (amount: number) => {
      const res = await apiRequest("POST", "/api/wallet/deposit", { amount });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
      toast({
        title: "Deposit Initiated",
        description: "Your deposit is being processed. This may take a few moments.",
      });
      
      // Refresh user data after a short delay to reflect updated balance
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      }, 3500);
    },
    onError: (error: Error) => {
      toast({
        title: "Deposit Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const withdrawMutation = useMutation({
    mutationFn: async (amount: number) => {
      const res = await apiRequest("POST", "/api/wallet/withdraw", { amount });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wallet/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] }); // Balance is updated immediately
      toast({
        title: "Withdrawal Requested",
        description: "Your withdrawal request has been submitted and is pending approval.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Withdrawal Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  const isTransactionPending = depositMutation.isPending || withdrawMutation.isPending;
  
  const deposit = (amount: number) => {
    depositMutation.mutate(amount);
  };
  
  const withdraw = (amount: number) => {
    withdrawMutation.mutate(amount);
  };
  
  return (
    <WalletContext.Provider
      value={{
        transactions,
        isLoading,
        deposit,
        withdraw,
        isTransactionPending,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
}
