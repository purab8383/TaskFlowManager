import { pgTable, text, serial, integer, boolean, timestamp, doublePrecision, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  balance: doublePrecision("balance").notNull().default(0),
  isAdmin: boolean("is_admin").notNull().default(false),
  clientSeed: text("client_seed").notNull(),
  clientSeedHash: text("client_seed_hash").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  amount: doublePrecision("amount").notNull(),
  type: text("type").notNull(), // 'deposit', 'withdraw', 'bet', 'win'
  status: text("status").notNull(), // 'pending', 'completed', 'rejected'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  betAmount: doublePrecision("bet_amount").notNull(),
  mineCount: integer("mine_count").notNull(),
  serverSeed: text("server_seed").notNull(),
  serverSeedHash: text("server_seed_hash").notNull(),
  clientSeed: text("client_seed").notNull(),
  nonce: integer("nonce").notNull(),
  result: json("result").notNull(), // {grid: [], mines: [], revealed: [], multiplier: number, cashout: number}
  profit: doublePrecision("profit").notNull(),
  status: text("status").notNull(), // 'active', 'won', 'lost'
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  balance: true,
  clientSeed: true,
  clientSeedHash: true,
});

export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const depositSchema = z.object({
  amount: z.number().positive("Amount must be positive"),
});

export const withdrawSchema = z.object({
  amount: z.number().positive("Amount must be positive"),
});

export const startGameSchema = z.object({
  betAmount: z.number().positive("Bet amount must be positive"),
  mineCount: z.number().int().min(1).max(24),
});

export const playMoveSchema = z.object({
  gameId: z.number(),
  tileIndex: z.number().int().min(0).max(24),
});

export const cashoutSchema = z.object({
  gameId: z.number(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginCredentials = z.infer<typeof loginSchema>;
export type DepositRequest = z.infer<typeof depositSchema>;
export type WithdrawRequest = z.infer<typeof withdrawSchema>;
export type StartGameRequest = z.infer<typeof startGameSchema>;
export type PlayMoveRequest = z.infer<typeof playMoveSchema>;
export type CashoutRequest = z.infer<typeof cashoutSchema>;

export type User = typeof users.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type Game = typeof games.$inferSelect;
