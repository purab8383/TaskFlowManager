import { storage } from './storage';
import { db } from './db';
import { games, transactions, users } from '@shared/schema';
import { eq, sql, desc, and, gte, lte, sum, count, avg } from 'drizzle-orm';
import { Transaction, Game, User } from '@shared/schema';

export async function getAllUsers() {
  return storage.getAllUsers();
}

export async function getPendingWithdrawals() {
  return storage.getPendingWithdrawals();
}

export async function approveWithdrawal(transactionId: number) {
  // In a real app, this would integrate with a payment processor
  return storage.updateTransactionStatus(transactionId, 'completed');
}

export async function rejectWithdrawal(transactionId: number, userId: number) {
  const transaction = await storage.updateTransactionStatus(transactionId, 'rejected');
  
  // Return the funds to the user since the withdrawal was rejected
  // The amount is stored as negative in withdrawals, so we negate it to add back
  await storage.updateUserBalance(userId, -transaction.amount);
  
  return transaction;
}

// Analytics functions

interface GameMetrics {
  totalGames: number;
  totalBetAmount: number;
  totalProfit: number;
  avgBetAmount: number;
  winRate: number;
  mostCommonMineCount: number;
}

interface UserMetrics {
  totalUsers: number;
  newUsersToday: number;
  newUsersThisWeek: number;
  newUsersThisMonth: number;
  activeUsers: number;
}

interface FinancialMetrics {
  totalDeposits: number;
  totalWithdrawals: number;
  totalBets: number;
  totalWins: number;
  netProfit: number;
  houseEdge: number;
}

interface TimeSeriesDataPoint {
  date: string;
  value: number;
}

interface AnalyticsDashboard {
  gameMetrics: GameMetrics;
  userMetrics: UserMetrics;
  financialMetrics: FinancialMetrics;
  recentGames: Game[];
  topUsers: {
    user: User;
    totalBets: number;
    totalWins: number;
    profit: number;
  }[];
  dailyRevenue: TimeSeriesDataPoint[];
  dailyNewUsers: TimeSeriesDataPoint[];
  dailyGamesPlayed: TimeSeriesDataPoint[];
}

// Get game metrics
export async function getGameMetrics(): Promise<GameMetrics> {
  // Total games
  const [totalGamesResult] = await db
    .select({ count: count() })
    .from(games);
  
  // Total bet amount and profit
  const [financialResult] = await db
    .select({
      totalBetAmount: sum(games.betAmount),
      totalProfit: sum(games.profit),
      avgBetAmount: avg(games.betAmount)
    })
    .from(games);
  
  // Win rate
  const [wonGamesResult] = await db
    .select({ count: count() })
    .from(games)
    .where(eq(games.status, 'won'));
  
  // Most common mine count
  const mineCountResults = await db
    .select({
      mineCount: games.mineCount,
      count: count()
    })
    .from(games)
    .groupBy(games.mineCount)
    .orderBy(desc(sql`count`))
    .limit(1);
  
  const totalGames = Number(totalGamesResult.count || 0);
  const wonGames = Number(wonGamesResult.count || 0);
  const winRate = totalGames > 0 ? (wonGames / totalGames) * 100 : 0;
  
  return {
    totalGames,
    totalBetAmount: Number(financialResult.totalBetAmount || 0),
    totalProfit: Number(financialResult.totalProfit || 0),
    avgBetAmount: Number(financialResult.avgBetAmount || 0),
    winRate,
    mostCommonMineCount: mineCountResults.length > 0 ? Number(mineCountResults[0].mineCount) : 5
  };
}

// Get user metrics
export async function getUserMetrics(): Promise<UserMetrics> {
  // Total users
  const [totalUsersResult] = await db
    .select({ count: count() })
    .from(users);
  
  // Get today's date at midnight
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Get date for 7 days ago
  const weekAgo = new Date(today);
  weekAgo.setDate(weekAgo.getDate() - 7);
  
  // Get date for 30 days ago
  const monthAgo = new Date(today);
  monthAgo.setDate(monthAgo.getDate() - 30);
  
  // New users today
  const [newUsersTodayResult] = await db
    .select({ count: count() })
    .from(users)
    .where(gte(users.createdAt, today));
  
  // New users this week
  const [newUsersThisWeekResult] = await db
    .select({ count: count() })
    .from(users)
    .where(gte(users.createdAt, weekAgo));
  
  // New users this month
  const [newUsersThisMonthResult] = await db
    .select({ count: count() })
    .from(users)
    .where(gte(users.createdAt, monthAgo));
  
  // Active users (users who played at least one game in the last 7 days)
  const activeUsersResult = await db
    .select({
      userId: games.userId
    })
    .from(games)
    .where(gte(games.createdAt, weekAgo))
    .groupBy(games.userId);
  
  return {
    totalUsers: totalUsersResult.count || 0,
    newUsersToday: newUsersTodayResult.count || 0,
    newUsersThisWeek: newUsersThisWeekResult.count || 0,
    newUsersThisMonth: newUsersThisMonthResult.count || 0,
    activeUsers: activeUsersResult.length
  };
}

// Get financial metrics
export async function getFinancialMetrics(): Promise<FinancialMetrics> {
  // Get deposits total
  const [depositResult] = await db
    .select({
      total: sum(transactions.amount)
    })
    .from(transactions)
    .where(
      and(
        eq(transactions.type, 'deposit'),
        eq(transactions.status, 'completed')
      )
    );
  
  // Get withdrawals total (withdrawals are stored as negative amounts)
  const [withdrawalResult] = await db
    .select({
      total: sum(transactions.amount)
    })
    .from(transactions)
    .where(
      and(
        eq(transactions.type, 'withdraw'),
        eq(transactions.status, 'completed')
      )
    );
  
  // Get bets total
  const [betResult] = await db
    .select({
      total: sum(games.betAmount)
    })
    .from(games);
  
  // Get wins total
  const [winResult] = await db
    .select({
      total: sum(games.profit)
    })
    .from(games)
    .where(eq(games.status, 'won'));
  
  const totalDeposits = Number(depositResult.total || 0);
  const totalWithdrawals = Math.abs(Number(withdrawalResult.total || 0));
  const totalBets = Number(betResult.total || 0);
  const totalWins = Number(winResult.total || 0);
  
  // Calculate net profit (bets - wins)
  const netProfit = totalBets - totalWins;
  
  // Calculate house edge as a percentage
  const houseEdge = totalBets > 0 ? (netProfit / totalBets) * 100 : 0;
  
  return {
    totalDeposits,
    totalWithdrawals,
    totalBets,
    totalWins,
    netProfit,
    houseEdge
  };
}

// Get recent games
export async function getRecentGames(limit: number = 10): Promise<Game[]> {
  return db
    .select()
    .from(games)
    .orderBy(desc(games.createdAt))
    .limit(limit);
}

// Get top users
export async function getTopUsers(limit: number = 5): Promise<any[]> {
  const topUsersQuery = await db.execute(sql`
    SELECT 
      u.id,
      u.username,
      u.email,
      u.balance,
      COUNT(g.id) as total_bets,
      SUM(CASE WHEN g.status = 'won' THEN 1 ELSE 0 END) as total_wins,
      SUM(g.profit) as profit
    FROM users u
    JOIN games g ON u.id = g.user_id
    GROUP BY u.id
    ORDER BY profit DESC
    LIMIT ${limit}
  `);
  
  const userResults = [];
  
  for (const row of topUsersQuery) {
    const user = await storage.getUser(row.id);
    if (user) {
      userResults.push({
        user,
        totalBets: Number(row.total_bets),
        totalWins: Number(row.total_wins),
        profit: Number(row.profit)
      });
    }
  }
  
  return userResults;
}

// Get daily revenue data for the last 30 days
export async function getDailyRevenue(): Promise<TimeSeriesDataPoint[]> {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const result = await db.execute(sql`
    SELECT 
      DATE(created_at) as date,
      SUM(bet_amount) - SUM(CASE WHEN status = 'won' THEN profit ELSE 0 END) as revenue
    FROM games
    WHERE created_at >= ${thirtyDaysAgo.toISOString()}
    GROUP BY DATE(created_at)
    ORDER BY date
  `);
  
  return result.map(row => ({
    date: new Date(row.date).toISOString().split('T')[0],
    value: Number(row.revenue) || 0
  }));
}

// Get daily new users for the last 30 days
export async function getDailyNewUsers(): Promise<TimeSeriesDataPoint[]> {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const result = await db.execute(sql`
    SELECT 
      DATE(created_at) as date,
      COUNT(*) as count
    FROM users
    WHERE created_at >= ${thirtyDaysAgo.toISOString()}
    GROUP BY DATE(created_at)
    ORDER BY date
  `);
  
  return result.map(row => ({
    date: new Date(row.date).toISOString().split('T')[0],
    value: Number(row.count)
  }));
}

// Get daily games played for the last 30 days
export async function getDailyGamesPlayed(): Promise<TimeSeriesDataPoint[]> {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const result = await db.execute(sql`
    SELECT 
      DATE(created_at) as date,
      COUNT(*) as count
    FROM games
    WHERE created_at >= ${thirtyDaysAgo.toISOString()}
    GROUP BY DATE(created_at)
    ORDER BY date
  `);
  
  return result.map(row => ({
    date: new Date(row.date).toISOString().split('T')[0],
    value: Number(row.count)
  }));
}

// Get complete analytics dashboard data
export async function getAnalyticsDashboard(): Promise<AnalyticsDashboard> {
  const [
    gameMetrics,
    userMetrics,
    financialMetrics,
    recentGames,
    topUsers,
    dailyRevenue,
    dailyNewUsers,
    dailyGamesPlayed
  ] = await Promise.all([
    getGameMetrics(),
    getUserMetrics(),
    getFinancialMetrics(),
    getRecentGames(),
    getTopUsers(),
    getDailyRevenue(),
    getDailyNewUsers(),
    getDailyGamesPlayed()
  ]);
  
  return {
    gameMetrics,
    userMetrics,
    financialMetrics,
    recentGames,
    topUsers,
    dailyRevenue,
    dailyNewUsers,
    dailyGamesPlayed
  };
}
