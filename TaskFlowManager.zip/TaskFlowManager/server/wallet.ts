import { storage } from './storage';
import { depositSchema, withdrawSchema } from '@shared/schema';
import { z } from 'zod';

export async function deposit(userId: number, amount: number) {
  try {
    // Validate request
    const validatedData = depositSchema.parse({ amount });
    
    // Get user
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    // Create a pending deposit transaction
    const transaction = await storage.createTransaction({
      userId,
      amount: validatedData.amount,
      type: 'deposit',
      status: 'pending',
    });
    
    // In a real app, this would integrate with a payment processor
    // For this demo, we'll auto-approve deposits after a brief delay
    setTimeout(async () => {
      try {
        // Update transaction to completed
        await storage.updateTransactionStatus(transaction.id, 'completed');
        
        // Update user balance
        await storage.updateUserBalance(userId, validatedData.amount);
      } catch (error) {
        console.error('Error auto-approving deposit:', error);
      }
    }, 3000);
    
    return transaction;
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new Error(`Invalid deposit parameters: ${error.errors[0].message}`);
    }
    throw error;
  }
}

export async function withdraw(userId: number, amount: number) {
  try {
    // Validate request
    const validatedData = withdrawSchema.parse({ amount });
    
    // Get user
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    // Check if user has enough balance
    if (user.balance < validatedData.amount) {
      throw new Error('Insufficient balance');
    }
    
    // Create a pending withdrawal transaction
    const transaction = await storage.createTransaction({
      userId,
      amount: -validatedData.amount, // Negative amount for withdrawals
      type: 'withdraw',
      status: 'pending',
    });
    
    // Immediately reduce the user's balance to prevent double spending
    await storage.updateUserBalance(userId, -validatedData.amount);
    
    return transaction;
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new Error(`Invalid withdrawal parameters: ${error.errors[0].message}`);
    }
    throw error;
  }
}

export async function getTransactions(userId: number) {
  return storage.getTransactionsByUserId(userId);
}
