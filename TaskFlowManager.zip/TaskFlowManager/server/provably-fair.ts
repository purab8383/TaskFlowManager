import * as crypto from 'crypto';

export interface MinesGameConfig {
  mineCount: number;
  gridSize: number;
}

// Generate a random server seed
export function generateServerSeed(): string {
  return crypto.randomBytes(32).toString('hex');
}

// Hash the server seed using SHA-256
export function hashServerSeed(serverSeed: string): string {
  return crypto.createHash('sha256').update(serverSeed).digest('hex');
}

// Generate mine positions based on the provided seeds
export function generateMines(
  serverSeed: string, 
  clientSeed: string, 
  nonce: number, 
  config: MinesGameConfig
): number[] {
  const { mineCount, gridSize } = config;
  
  // Ensure we don't try to place more mines than we have grid spaces
  const actualMineCount = Math.min(mineCount, gridSize);
  
  // Use Fisher-Yates shuffle to create random mine positions
  // This is much more efficient than the previous approach
  const positions: number[] = [];
  
  // First, create an array of all possible positions
  for (let i = 0; i < gridSize; i++) {
    positions.push(i);
  }
  
  // Create a random seed using server seed, client seed, and nonce
  const combinedSeed = `${serverSeed}-${clientSeed}-${nonce}`;
  
  // Create a PRNG function using the hash as seed
  const hash = crypto.createHash('sha256').update(combinedSeed).digest('hex');
  
  // Use the hash to shuffle the positions array
  for (let i = positions.length - 1; i > 0; i--) {
    // Get a value from the hash at position corresponding to index
    const hashPos = i % (hash.length - 8);
    const slice = hash.substring(hashPos, hashPos + 8);
    const decimal = parseInt(slice, 16);
    
    // Use the value to pick a random index from 0 to i
    const j = decimal % (i + 1);
    
    // Swap positions[i] and positions[j]
    [positions[i], positions[j]] = [positions[j], positions[i]];
  }
  
  // Take the first actualMineCount elements as mine positions
  const mines = positions.slice(0, actualMineCount);
  
  return mines.sort((a, b) => a - b);
}

// Generate multipliers for tiles based on the number of mines and game stage
export function generateMultipliers(
  mineCount: number, 
  revealedCount: number
): number[] {
  const totalTiles = 25;
  const safeTiles = totalTiles - mineCount;
  
  // Base multiplier calculation
  // The formula is designed to give increasing rewards as more tiles are revealed
  // This is a simple implementation - a real casino would use more complex calculations
  // based on probability theory
  
  // Calculate base multiplier using house edge (e.g., 3%)
  const houseEdge = 0.03;
  const probability = (safeTiles - revealedCount) / (totalTiles - revealedCount);
  const fairMultiplier = 1 / probability;
  const multiplier = fairMultiplier * (1 - houseEdge);
  
  return [multiplier];
}

// Verify a game's result
export function verifyGame(
  serverSeed: string,
  clientSeed: string,
  nonce: number,
  config: MinesGameConfig
): boolean {
  // Hash the server seed
  const serverSeedHash = hashServerSeed(serverSeed);
  
  // Generate mines
  const mines = generateMines(serverSeed, clientSeed, nonce, config);
  
  // A real implementation would verify these against stored game results
  // For this example, we just return that the verification passed
  return true;
}
