import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { startGame, playMove, cashout } from "./game";
import { deposit, withdraw, getTransactions } from "./wallet";
import { 
  getAllUsers, 
  getPendingWithdrawals, 
  approveWithdrawal, 
  rejectWithdrawal,
  getAnalyticsDashboard,
  getGameMetrics,
  getUserMetrics,
  getFinancialMetrics,
  getRecentGames,
  getTopUsers,
  getDailyRevenue,
  getDailyNewUsers,
  getDailyGamesPlayed
} from "./admin";
import rateLimit from "express-rate-limit";

// Middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

// Middleware to check if user is an admin
const isAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (req.isAuthenticated() && req.user.isAdmin) {
    return next();
  }
  res.status(403).json({ message: "Forbidden" });
};

// Rate limiting middleware to prevent abuse
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // Apply rate limiting to all API routes
  app.use("/api", apiLimiter);

  // Game routes
  app.post("/api/games", isAuthenticated, async (req, res, next) => {
    try {
      const { betAmount, mineCount } = req.body;
      const game = await startGame(req.user.id, betAmount, mineCount);
      res.status(201).json(game);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/games/:id/tiles/:index", isAuthenticated, async (req, res, next) => {
    try {
      const gameId = parseInt(req.params.id);
      const tileIndex = parseInt(req.params.index);
      const result = await playMove(req.user.id, gameId, tileIndex);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/games/:id/cashout", isAuthenticated, async (req, res, next) => {
    try {
      const gameId = parseInt(req.params.id);
      const result = await cashout(req.user.id, gameId);
      res.json(result);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/games", isAuthenticated, async (req, res, next) => {
    try {
      const games = await storage.getGamesByUserId(req.user.id);
      res.json(games);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/games/:id", isAuthenticated, async (req, res, next) => {
    try {
      const gameId = parseInt(req.params.id);
      const game = await storage.getGame(gameId);
      
      if (!game) {
        return res.status(404).json({ message: "Game not found" });
      }
      
      if (game.userId !== req.user.id) {
        return res.status(403).json({ message: "Forbidden" });
      }
      
      res.json(game);
    } catch (error) {
      next(error);
    }
  });

  // Wallet routes
  app.post("/api/wallet/deposit", isAuthenticated, async (req, res, next) => {
    try {
      const { amount } = req.body;
      const transaction = await deposit(req.user.id, amount);
      res.status(201).json(transaction);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/wallet/withdraw", isAuthenticated, async (req, res, next) => {
    try {
      const { amount } = req.body;
      const transaction = await withdraw(req.user.id, amount);
      res.status(201).json(transaction);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/wallet/transactions", isAuthenticated, async (req, res, next) => {
    try {
      const transactions = await getTransactions(req.user.id);
      res.json(transactions);
    } catch (error) {
      next(error);
    }
  });

  // Admin routes
  app.get("/api/admin/users", isAdmin, async (req, res, next) => {
    try {
      const users = await getAllUsers();
      res.json(users);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/admin/withdrawals", isAdmin, async (req, res, next) => {
    try {
      const withdrawals = await getPendingWithdrawals();
      res.json(withdrawals);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/admin/withdrawals/:id/approve", isAdmin, async (req, res, next) => {
    try {
      const transactionId = parseInt(req.params.id);
      const transaction = await approveWithdrawal(transactionId);
      res.json(transaction);
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/admin/withdrawals/:id/reject", isAdmin, async (req, res, next) => {
    try {
      const transactionId = parseInt(req.params.id);
      const { userId } = req.body;
      const transaction = await rejectWithdrawal(transactionId, userId);
      res.json(transaction);
    } catch (error) {
      next(error);
    }
  });

  // Analytics endpoints
  app.get("/api/admin/analytics/dashboard", isAdmin, async (req, res, next) => {
    try {
      const dashboardData = await getAnalyticsDashboard();
      res.json(dashboardData);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/analytics/game-metrics", isAdmin, async (req, res, next) => {
    try {
      const metrics = await getGameMetrics();
      res.json(metrics);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/analytics/user-metrics", isAdmin, async (req, res, next) => {
    try {
      const metrics = await getUserMetrics();
      res.json(metrics);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/analytics/financial-metrics", isAdmin, async (req, res, next) => {
    try {
      const metrics = await getFinancialMetrics();
      res.json(metrics);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/analytics/recent-games", isAdmin, async (req, res, next) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const games = await getRecentGames(limit);
      res.json(games);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/analytics/top-users", isAdmin, async (req, res, next) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const users = await getTopUsers(limit);
      res.json(users);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/analytics/daily-revenue", isAdmin, async (req, res, next) => {
    try {
      const data = await getDailyRevenue();
      res.json(data);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/analytics/daily-new-users", isAdmin, async (req, res, next) => {
    try {
      const data = await getDailyNewUsers();
      res.json(data);
    } catch (error) {
      next(error);
    }
  });
  
  app.get("/api/admin/analytics/daily-games-played", isAdmin, async (req, res, next) => {
    try {
      const data = await getDailyGamesPlayed();
      res.json(data);
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
