import { users, transactions, games, type User, type InsertUser, type Transaction, type Game } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

// Game result type for in-memory storage
export interface GameResult {
  grid: Array<number>;  // Contains multipliers for each tile
  mines: Array<number>; // Indices of mines
  revealed: Array<number>; // Indices of revealed tiles
  multiplier: number;  // Current multiplier
  cashout: number | null; // Cashed out amount or null if not cashed out
}

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserBalance(userId: number, amount: number): Promise<User>;
  updateUserClientSeed(userId: number, clientSeed: string, clientSeedHash: string): Promise<User>;

  // Transaction operations
  createTransaction(transaction: Omit<Transaction, 'id' | 'createdAt'>): Promise<Transaction>;
  getTransactionsByUserId(userId: number): Promise<Transaction[]>;
  updateTransactionStatus(id: number, status: string): Promise<Transaction>;

  // Game operations
  createGame(game: Omit<Game, 'id' | 'createdAt'>): Promise<Game>;
  getGame(id: number): Promise<Game | undefined>;
  getGamesByUserId(userId: number): Promise<Game[]>;
  updateGameResult(id: number, result: any, profit: number, status: string): Promise<Game>;

  // Admin operations
  getAllUsers(): Promise<User[]>;
  getPendingWithdrawals(): Promise<Transaction[]>;

  // Session store for authentication
  sessionStore: any; // Using any to avoid TypeScript issues with session store types
}

export class DatabaseStorage implements IStorage {
  public sessionStore: any; // Using any to avoid TypeScript issues with session store types

  constructor() {
    const PostgresSessionStore = connectPg(session);
    this.sessionStore = new PostgresSessionStore({ 
      pool,
      createTableIfMissing: true 
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username.toLowerCase()));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase()));
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    // Use provided seed or generate one
    const clientSeed = userData.clientSeed || Math.random().toString(36).substring(2, 15);
    const clientSeedHash = userData.clientSeedHash || clientSeed; // In a real app, this would be a hash

    // Default balance is 100 for new users
    const balance = userData.balance !== undefined ? userData.balance : 100;

    const [user] = await db
      .insert(users)
      .values({
        ...userData,
        balance,
        isAdmin: false,
        clientSeed,
        clientSeedHash,
      })
      .returning();
    return user;
  }

  async updateUserBalance(userId: number, amount: number): Promise<User> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId));
    
    if (!user) {
      throw new Error("User not found");
    }
    
    const [updatedUser] = await db
      .update(users)
      .set({ balance: user.balance + amount })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateUserClientSeed(userId: number, clientSeed: string, clientSeedHash: string): Promise<User> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, userId));
    
    if (!user) {
      throw new Error("User not found");
    }
    
    const [updatedUser] = await db
      .update(users)
      .set({ clientSeed, clientSeedHash })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  // Transaction operations
  async createTransaction(transactionData: Omit<Transaction, 'id' | 'createdAt'>): Promise<Transaction> {
    const [transaction] = await db
      .insert(transactions)
      .values(transactionData)
      .returning();
    
    return transaction;
  }

  async getTransactionsByUserId(userId: number): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async updateTransactionStatus(id: number, status: string): Promise<Transaction> {
    const [transaction] = await db
      .select()
      .from(transactions)
      .where(eq(transactions.id, id));
    
    if (!transaction) {
      throw new Error("Transaction not found");
    }
    
    const [updatedTransaction] = await db
      .update(transactions)
      .set({ status })
      .where(eq(transactions.id, id))
      .returning();
    
    return updatedTransaction;
  }

  // Game operations
  async createGame(gameData: Omit<Game, 'id' | 'createdAt'>): Promise<Game> {
    const [game] = await db
      .insert(games)
      .values(gameData)
      .returning();
    
    return game;
  }

  async getGame(id: number): Promise<Game | undefined> {
    const [game] = await db
      .select()
      .from(games)
      .where(eq(games.id, id));
    
    return game;
  }

  async getGamesByUserId(userId: number): Promise<Game[]> {
    return await db
      .select()
      .from(games)
      .where(eq(games.userId, userId))
      .orderBy(desc(games.createdAt));
  }

  async updateGameResult(id: number, result: any, profit: number, status: string): Promise<Game> {
    const [game] = await db
      .select()
      .from(games)
      .where(eq(games.id, id));
    
    if (!game) {
      throw new Error("Game not found");
    }
    
    const [updatedGame] = await db
      .update(games)
      .set({ result, profit, status })
      .where(eq(games.id, id))
      .returning();
    
    return updatedGame;
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getPendingWithdrawals(): Promise<Transaction[]> {
    return await db
      .select()
      .from(transactions)
      .where(
        and(
          eq(transactions.type, 'withdraw'),
          eq(transactions.status, 'pending')
        )
      )
      .orderBy(transactions.createdAt);
  }
}

export const storage = new DatabaseStorage();
