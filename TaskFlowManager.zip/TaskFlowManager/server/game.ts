import { storage } from './storage';
import { 
  generateServerSeed, 
  hashServerSeed, 
  generateMines, 
  generateMultipliers 
} from './provably-fair';
import { GameResult } from './storage';
import { z } from 'zod';
import { startGameSchema, playMoveSchema, cashoutSchema } from '@shared/schema';

export async function startGame(userId: number, betAmount: number, mineCount: number) {
  try {
    // Validate request
    const validatedData = startGameSchema.parse({ betAmount, mineCount });
    
    // Get user
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    // Check if user has enough balance
    if (user.balance < betAmount) {
      throw new Error('Insufficient balance');
    }
    
    // Generate game parameters
    const serverSeed = generateServerSeed();
    const serverSeedHash = hashServerSeed(serverSeed);
    const clientSeed = user.clientSeed;
    const nonce = Math.floor(Math.random() * 1000000); // In a real app this would be a sequence
    
    // Generate mines
    const mines = generateMines(serverSeed, clientSeed, nonce, { mineCount, gridSize: 25 });
    
    // Initialize result object
    const result: GameResult = {
      grid: Array(25).fill(0),  // Will be populated with multipliers as tiles are revealed
      mines,
      revealed: [],
      multiplier: 1,
      cashout: null
    };
    
    // Create game record
    const game = await storage.createGame({
      userId,
      betAmount,
      mineCount,
      serverSeed,
      serverSeedHash,
      clientSeed,
      nonce,
      result,
      profit: -betAmount, // Start with negative profit (bet amount)
      status: 'active',
    });
    
    // Deduct bet amount from user balance
    await storage.updateUserBalance(userId, -betAmount);
    
    // Create transaction record for the bet
    await storage.createTransaction({
      userId,
      amount: -betAmount,
      type: 'bet',
      status: 'completed',
    });
    
    // Return game without revealing the server seed
    return {
      id: game.id,
      betAmount: game.betAmount,
      mineCount: game.mineCount,
      serverSeedHash: game.serverSeedHash,
      clientSeed: game.clientSeed,
      nonce: game.nonce,
      status: game.status,
      createdAt: game.createdAt,
    };
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new Error(`Invalid game parameters: ${error.errors[0].message}`);
    }
    throw error;
  }
}

export async function playMove(userId: number, gameId: number, tileIndex: number) {
  try {
    // Validate request
    const validatedData = playMoveSchema.parse({ gameId, tileIndex });
    
    // Get game
    const game = await storage.getGame(gameId);
    if (!game) {
      throw new Error('Game not found');
    }
    
    // Verify ownership
    if (game.userId !== userId) {
      throw new Error('Unauthorized');
    }
    
    // Check if game is active
    if (game.status !== 'active') {
      throw new Error('Game is not active');
    }
    
    // Get current game result
    const result = game.result as GameResult;
    
    // Check if tile has already been revealed
    if (result.revealed.includes(tileIndex)) {
      throw new Error('Tile already revealed');
    }
    
    // Check if tile is a mine
    if (result.mines.includes(tileIndex)) {
      // Player hit a mine, game over
      result.revealed.push(tileIndex);
      
      // Update game result
      const updatedGame = await storage.updateGameResult(
        gameId,
        result,
        -game.betAmount, // Loss is the bet amount
        'lost'
      );
      
      // Create transaction record for the loss (balance was already deducted when game started)
      await storage.createTransaction({
        userId,
        amount: -game.betAmount,
        type: 'loss',
        status: 'completed',
      });
      
      // Force a balance refresh by making a zero-value update
      // This ensures the database record is touched and the client sees up-to-date data
      await storage.updateUserBalance(userId, 0);
      
      // Return the updated game with all mines revealed
      return {
        ...updatedGame,
        result: {
          ...result,
          mines: result.mines, // Now reveal all mine positions
        }
      };
    }
    
    // Safe tile, calculate new multiplier
    result.revealed.push(tileIndex);
    
    // Calculate multiplier for this stage
    const multipliers = generateMultipliers(game.mineCount, result.revealed.length);
    const currentMultiplier = multipliers[0];
    result.multiplier = currentMultiplier;
    
    // Add the multiplier to the grid
    result.grid[tileIndex] = currentMultiplier;
    
    // Update game
    const updatedGame = await storage.updateGameResult(
      gameId,
      result,
      -game.betAmount, // Still showing as a loss until cashed out
      'active'
    );
    
    // Return the updated game without revealing mines
    return {
      ...updatedGame,
      result: {
        ...result,
        mines: [], // Don't reveal mines during active game
      }
    };
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new Error(`Invalid move parameters: ${error.errors[0].message}`);
    }
    throw error;
  }
}

export async function cashout(userId: number, gameId: number) {
  try {
    // Validate request
    const validatedData = cashoutSchema.parse({ gameId });
    
    // Get game
    const game = await storage.getGame(gameId);
    if (!game) {
      throw new Error('Game not found');
    }
    
    // Verify ownership
    if (game.userId !== userId) {
      throw new Error('Unauthorized');
    }
    
    // Check if game is active
    if (game.status !== 'active') {
      throw new Error('Game is not active');
    }
    
    // Get current game result
    const result = game.result as GameResult;
    
    // Calculate winnings
    const winAmount = game.betAmount * result.multiplier;
    const profit = winAmount - game.betAmount;
    
    // Update result with cashout
    result.cashout = winAmount;
    
    // Update game
    const updatedGame = await storage.updateGameResult(
      gameId,
      result,
      profit,
      'won'
    );
    
    // Update user balance
    await storage.updateUserBalance(userId, winAmount);
    
    // Create transaction record for the win
    await storage.createTransaction({
      userId,
      amount: winAmount,
      type: 'win',
      status: 'completed',
    });
    
    // Return the updated game with all mines revealed
    return {
      ...updatedGame,
      result: {
        ...result,
        mines: result.mines, // Now reveal all mine positions
      }
    };
    
  } catch (error) {
    if (error instanceof z.ZodError) {
      throw new Error(`Invalid cashout parameters: ${error.errors[0].message}`);
    }
    throw error;
  }
}
